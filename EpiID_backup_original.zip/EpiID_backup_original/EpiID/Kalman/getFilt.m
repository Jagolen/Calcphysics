function KF = getFilt(Sys,ver)
%GETFILT state- and covariance matrices for compartment model.
%   KF = GETFILT(SYS) produces a Kalman filter KF for the compartment
%   model SYS, see getSYST.
%
%   On return, KF contains four fields:
%
%   -F: State update matrix (i.e., x_{k+1} = F*x_k).
%
%   -Qp: State dependent covariance based on a Poisson assumption,
%   Qp(:,:,i) defines the contribution of the covariance from state
%   x_i according to Q_i = Qp(:,:,i)*x_i, total covariance =
%   sum_i(Q_i).
%   
%   -Qv: State dependent variance proportional to square flows (i.e.,
%   incidence). Qv(i,k) defines the contribution from state k to the
%   variance of state i (no covariance between states is included in
%   this) according to Q_i = sum_k(Qv(i,k)*x_k^2).
%
%   -Q0: Constant diagonal covariance matrix contribution.
%
%   -qdiag: vector relative covariance contribution
%   diag(qdiag.*(Qv*xx.^2)).
%
%   -CStates: logical array identifying the cumulative states of the
%   system (states without outgoing transitions in the transition
%   matrix or added cumulative states as defined by SYS.CStates)
%
%   See also getSYST.

% S. Engblom 2022-12-14 (Major revision, new input format) 
% S. Engblom 2022-05-08 (Based on code getC19filt)

% S. Engblom 2021-02-28 (Revision)
% H. Runvik 2020-11-18
% H. Runvik 2020-10-25
% H. Runvik 2020-10-21 (Revision)
% H. Runvik 2020-09-14

% silent support: version (ver = 2 is deprecated)
if nargin < 2, ver = 1; end

if ver == 1
  % convenience
  DStates = Sys.DStates;
  CStates = Sys.CStates;
  IStates = Sys.IStates;
  AStates = Sys.AStates;

  % propensity Jacobian and stoichiometric matrix
  pJac = Sys.pJac;
  N = Sys.N;

  % sizes
  Nb = size(pJac,2);    % "bulk"
  Nc = numel(CStates);  % cumulative states
  Ni = numel(IStates);  % incidence states
  Ntot = Nb+Nc+Ni;

  % checks
  assert(all(pJac(:) >= 0 | isnan(pJac(:))), ...
         'Negative transition rate.');
  assert(all(N(AStates,:) >= 0,'all'), ...
         'Transition from removed state.');

  % determine all cumulative states
  KF.CStates = [all(N >= 0,2); true(Nc,1); false(Ni,1)];
  KF.CStates(DStates) = false; % *** can be discussed?
  KF.CStates(AStates) = [];

  % the topology of the cumulative and the incidence states is found by
  % removing all outgoing transitions
  Ncum = N(CStates,:); Ncum(Ncum < 0) = 0;
  Ninc = N(IStates,:); Ninc(Ninc < 0) = 0;

  % new topology and propensity Jacobian
  N = [N; Ncum; Ninc];
  pJac = [pJac zeros(size(pJac,1),Ntot-Nb)];

  % operators can now be deduced
  d = ones(Ntot,1);
  % no accumulation for incidence variables:
  d(end-Ni+1:end) = 0;
  % ditto deterministic variables (they are "set" at each time):
  %d(DStates) = 0; % *** new syntax!
  F = diag(d)+N*pJac;
  Qp = tprod(tprod(N,N,[1 3],[2 3]),pJac,[1 2 -1],[-1 3]);
  Qv = N.^2*pJac.^2;
  % no Poissonian contribution to deterministic states:
  Qp(DStates,DStates,:) = 0;
  Qv(DStates,DStates) = 0; % *** seems mildly incorrect?

  % handle removed states
  F(AStates,:) = [];
  F(:,AStates) = [];
  Qp(AStates,:,:) = [];
  Qp(:,AStates,:) = [];
  Qp(:,:,AStates) = [];
  Qv(AStates,:) = [];
  Qv(:,AStates) = [];

  % final assign
  KF.F = F;
  KF.Qp = Qp;
  KF.Qv = Qv;

  % covariance model for diagonal
  KF.Q0 = spdiags(Sys.Q0,0,Ntot,Ntot);
  KF.qdiag = Sys.qdiag(:);

  return;
end

% convenience
CStates = Sys.CStates;
DStates = Sys.DStates;
AStates = Sys.AStates;
IStates = Sys.IStates;

% sizes
N = size(Sys.transMat,2); % "bulk"
Nc = numel(CStates);  % cumulative states
Ni = numel(IStates);  % incidense states
Ntot = N+Nc+Ni;

% convenience
transMat = Sys.transMat;
if ~isempty(Sys.DStates)
  dMat = Sys.dMat;
else
  dMat = zeros(0,N);
end

% checks
assert(all(size(dMat) == [numel(DStates) N]), ...
       'Incompatible sizes.');
assert(all(transMat(:,DStates) == 0,'all'), ...
       'Transition into deterministic state.');
assert(all(diag(transMat) == 0), ...
       'Transition into self.');
assert(all(transMat(AStates,:) == 0,'all'), ...
       'Transition from removed state.');
assert(all(dMat(:,AStates) == 0,'all'), ...
       'Transition from removed state into deterministic state.');
checkD = true(1,N); checkD(DStates) = false;
assert(all(checkD(CStates)) && all(checkD(IStates)), ...
       'Deterministic state does not support incidence/accumulation.');

% construct all cumulative states
allCStates = all(transMat == 0,2);
allCStates(AStates) = [];
KF.CStates = [allCStates; true(Nc,1); false(Ni,1)];

% start from no transitions
F = eye(N);
Qp = zeros(N,N,N);

% (1) bulk transitions
F = F+transMat'-diag(sum(transMat,2));
Qv = (transMat').^2+diag(sum(transMat.^2,2));
%Qv(DStates,DStates) = 0; % (not needed - done later)
for k1 = 1:N % FROM deterministic/stochastic state
  v = transMat(k1,:);
  Qp(:,:,k1) = diag(v);
  if checkD(k1) % FROM stochastic state
    Qp(k1,k1,k1) = Qp(k1,k1,k1)+sum(v,2); % add variance
    Qp(k1,:,k1) = Qp(k1,:,k1)-v;          % covariance
    Qp(:,k1,k1) = Qp(:,k1,k1)-v';         % covariance
  end
end

% (2) cumulative states
F = [F; F(CStates,:)];                % base state
F((N+1:N+Nc)+(CStates-1)*(N+Nc)) = 0; % remove coupling to base state
Qv = [Qv; Qv(CStates,:)];
Qv((N+1:N+Nc)+(CStates-1)*(N+Nc)) = 0;
Qp = [[Qp; zeros(Nc,N,N)] zeros(N+Nc,Nc,N)];
for k = 1:Nc
  k2 = 1:N;
  k2(CStates(k)) = [];
  Qp(N+k,:,k2) = Qp(CStates(k),:,k2);
  Qp(:,N+k,k2) = Qp(:,CStates(k),k2);
  Qp(N+k,N+k,k2) = Qp(CStates(k),CStates(k),k2);
end

% (3) incidence states
F = [F; F(IStates,:)];                 % base state
F((N+Nc+1:Ntot)+(IStates-1)*Ntot) = 0; % remove coupling to base state
Qv = [Qv; Qv(IStates,:)];
Qv((N+Nc+1:Ntot)+(IStates-1)*Ntot) = 0;
Qp = [[Qp; zeros(Ni,N+Nc,N)] zeros(N+Nc+Ni,Ni,N)];
for k = 1:Ni
  k2 = 1:N;
  k2(IStates(k)) = [];
  Qp(N+Nc+k,:,k2) = Qp(IStates(k),:,k2);
  Qp(:,N+Nc+k,k2) = Qp(:,IStates(k),k2);
  Qp(N+Nc+k,N+Nc+k,k2) = Qp(IStates(k),IStates(k),k2);
end

% (4) deterministic states
F(DStates,:) = dMat;
Qv(DStates,:) = dMat.^2;
Qv(DStates,DStates) = 0;

% (5) pad with zeros, remove unwanted states
F = [F zeros(Ntot,Nc+Ni)];
F((N+1:N+Nc)+(N:N+Nc-1)*Ntot) = 1; % "cumulative diagonal one's"
F(AStates,:) = [];
F(:,AStates) = [];

Na = numel(AStates); % "true" Ntot = Ntot-Na
Qp(AStates,:,:) = [];
Qp(:,AStates,:) = [];
Qp(:,:,AStates) = [];
Qp = cat(3,Qp,zeros(Ntot-Na,Ntot-Na,Nc+Ni));

Qv(AStates,:) = [];
Qv(:,AStates) = [];
Qv = [Qv zeros(Ntot-Na,Nc+Ni)];

% final assign
KF.F = F;
KF.Qp = Qp;
KF.Qv = Qv;

% covariance model for diagonal
KF.Q0 = spdiags(Sys.Q0,0,N,N);
KF.qdiag = Sys.qdiag(:);
