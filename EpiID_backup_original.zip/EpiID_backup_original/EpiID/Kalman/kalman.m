function [x,P,L] = kalman(x0,P0,KF,y,DF,smooth,varargin)
%KALMAN Kalman filtering.
%   [x,P,L] = KALMAN(x0,P0,KF,y,DF) uses the Kalman filter defined by
%   KF (see getFILT) and the measurements defined by DF (see getOBS)
%   in y, to produce state estimates x and covariance matrix P. x0 and
%   P0 are the initial state and covariance, respectively, see
%   initFILT.
%
%   The marginal likelihood L of data y given the model is also
%   returned in the form of a structure L with fields L.res
%   (residuals), L.Scov (innovation covariances), and L.logL.
%
%   The state estimate x has the following structure: x(:,1) and
%   x(:,2) contain the a priori- and a posteriori state estimate and
%   P(:,:,1) and P(:,:,2) contain the a priori- and a posteriori
%   covariances.
%
%   [...] = KALMAN(...,'rts') returns the result of additionally
%   applying the Rauch–Tung–Striebel smoother. In this syntax x(:,3)
%   and P(:,:,3), respecitvely, contain the smoothed paths using this
%   syntax. Also, L is augmented with fields L.res_rts, L.Scov_rts,
%   and L.logL_rts.
%
%   [...] = KALMAN(...,'rts',P0,P1,...) understand KF to be a function
%   with the signature KF(P0,P1,...,i), where P0, P1, etc are
%   parameters and where i is the index over data (starting from
%   1). This supports a time-dependent filter.
%
%   The Kalman filter is defined by the following fields:
%
%   Field     Definition
%   ------------------------------------------------------------------
%   KF.F      State update matrix, x_{i+1} = F*x_i.
%
%   KF.Qp     Contribution to the covariance from state x_i
%             according to Q_i = Qp(:,:,i)*x_i, Q = sum(Q_i).
%
%   KF.Qv     Qv, Q0, and qdiag, define additional uncertainties
%   KF.Q0     according to Q = Q+Q0+diag(qdiag.*(Qv*xx.^2)).
%   KF.qdiag
%
%   DF.H      Measurement operator, y_i = H*x_i.
%
%   DF.R0     The measurement noise covariance computed by the
%   DF.rdiag  formula R = R0+diag(rdiag.*(H*xx).^2).
%
%   See also getFILT, getOBS, initFILT.

% S. Engblom 2022-12-08 (time-dependent filter)
% S. Engblom 2022-12-07 (new syntax and the RTS-smoother)
% S. Engblom 2022-05-08 (based on code C19filt_kalman)

% S. Engblom 2021-05-15 (exception log)
% R. Eriksson 2021-01-28 (merge with dynamical_beta branch)
% H. Runvik 2020-11-19 (New qdiag formula)
% S. Engblom 2020-10-17 (Bugfix prior on (x0,P0))
% S. Engblom 2020-10-16 (Additional output L)
% S. Engblom 2020-10-15 (Speed improvements)
% H. Runvik 2020-09-14

if nargin < 6
  smooth = false;
else
  smooth = strcmpi(smooth,'rts');
end

isfunK = isa(KF,'function_handle');
if ~isfunK
  % static Kalman filter: dynamics
  F = KF.F;
  % (change into more effective format:)
  Qp = sparse(reshape(KF.Qp,[],size(KF.Qp,3)));
  Qv = KF.Qv;
  Q0 = KF.Q0;
  qdiag = KF.qdiag;
else
  % dynamic filter via function
  params = varargin;
  KF_ = KF(params{:},1);
  F = KF_.F;
  % *** clumsy to build the first filter; then build it anew in the main
  % loop below
end

% check sizes of initial state and data
assert(all(size(F) == size(x0,1)) && size(x0,2) == 1);
assert(all(size(F) == size(P0)));
assert(all(size(DF.H) == [size(y,1) size(x0,1)]));

% sizes
Nstate = size(F,2);
Id = speye(Nstate,Nstate);

% Kalman filter: measurements
H = DF.H;
R0 = DF.R0;
rdiag = DF.rdiag;

% allocate filter output
Mdata = size(y,1);
Ndata = size(y,2);
x = zeros(size(x0,1),Ndata,2);
P = zeros(size(P0,1),size(P0,2),Ndata,2);
if nargout > 2
  L.res = zeros(Mdata,Ndata);
  L.Scov = zeros(Mdata,Mdata,Ndata);
  L.logL = zeros(1,Ndata);

  SAFETY = double(realmin('single'))*realmax;
  LB = -10;
  UB = 1e6;
  AbsMagn = 1e4;
  SDFAC = 0.25;
end

% initial state
xx = x0;
PP = P0;

for i = 1:Ndata
  if isfunK
    KF_ = KF(params{:},i);
    F = KF_.F;
    Qp = sparse(reshape(KF_.Qp,[],size(KF_.Qp,3)));
    Qv = KF_.Qv;
    Q0 = KF_.Q0;
    qdiag = KF_.qdiag;
  end

  % additive noise model (covariance)
  Q = reshape(Qp*xx,Nstate,Nstate);
  
  % add offset and rate-dependent covariance
  Q = Q+Q0+diag(qdiag.*(Qv*xx.^2));

  % a priori
  xx = F*xx;
  PP = F*PP*F'+Q;

  % a priori
  x(:,i,1) = xx;
  P(:,:,i,1) = PP;

  % exceptional: check for NaN in measurement
  yNum = y(:,i);
  Hmod = H;
  if any(isnan(yNum))
    ixn = find(~isnan(yNum));
    Z = sparse(ixn,ixn,1,Mdata,Mdata);
    % remove them:
    yNum = Z*yNum;
    Hmod = Z*H;
  end

  % pre-fit residual
  yy = yNum-Hmod*xx;

  % update
  R = R0+diag(rdiag.*(Hmod*xx).^2);
  S = Hmod*PP*Hmod'+R;
  K = PP*Hmod'/S;

  % updated likelihood
  if nargout > 2 && size(yy,1) > 0
    % (note: unclear what to return if det < 0, but likely better to have
    % it non-silent and investigate...)
    L.res(:,i) = yy;   % ***
    L.Scov(:,:,i) = S; % *** bug here: S may change size
    L.logL(i) = -0.5*(yy'*(S\yy)+log(det(S))+size(yy,1)*log(2*pi));
    
    % check
    if L.logL(i) < -SAFETY || ...   % very small likelihood?
          ~isreal(L.logL(i)) || ... % oops! went imaginary!
          isnan(L.logL(i)) || ...   % oops! went NaN!
          any(xx < LB) || ...       % mean outside bounds [LB,UB]
          any(UB < xx) || ...
          any(diag(PP) < 0) || ...  % negative diagonal
          any(AbsMagn < xx & xx.^2 < SDFAC^2*diag(PP))
      L.logL(i) = -inf;
    end
  end

  % a posteriori
  xx = xx+K*yy;
  PP = (Id-K*Hmod)*PP;
  x(:,i,2) = xx;
  P(:,:,i,2) = PP;
end

% optional smoothing
if smooth
  xs = zeros(Nstate,Ndata);
  Ps = zeros(Nstate,Nstate,Ndata);
  xs(:,end) = xx;
  Ps(:,:,end) = PP;

  % Rauch–Tung–Striebel smoother through backward recursion
  for i = Ndata-1:-1:1
    if isfunK
      KF_ = KF(params{:},i+1);
      F = KF_.F;
    end
    C = P(:,:,i,2)*F'/P(:,:,i+1,1);
    xx = x(:,i,2)+C*(xx-x(:,i+1,1));
    PP = P(:,:,i,2)+C*(PP-P(:,:,i+1,1))*C';
    xs(:,i) = xx;
    Ps(:,:,i) = PP;
  end

  % append smoothed path by the end
  x = cat(3,x,xs);
  P = cat(4,P,Ps);

  % smoothed likelihood
  if nargout > 2
    for i = 1:Ndata
      yNum = y(:,i);
      Hmod = H;
      if any(isnan(yNum))
        ixn = find(~isnan(yNum));
        Z = sparse(ixn,ixn,1,Mdata,Mdata);
        % remove them:
        yNum = Z*yNum;
        Hmod = Z*H;
      end

      ys = yNum-Hmod*xs(:,i);

      R = R0+diag(rdiag.*(Hmod*xs(:,i)).^2);
      S = Hmod*Ps(:,:,i)*Hmod'+R;
      K = Ps(:,:,i)*Hmod'/S;

      L.res_rts(:,i) = ys;
      L.Scov_rts(:,:,i) = S;
      L.logL_rts(i) = -0.5*(ys'*(S\ys)+log(det(S))+size(ys,1)*log(2*pi));
    
      if L.logL_rts(i) < -SAFETY || ...
            ~isreal(L.logL(i)) || ...
            isnan(L.logL(i)) || ...
            any(xs(:,i) < LB) || ...
            any(UB < xs(:,i)) || ...
            any(diag(Ps(:,:,i)) < 0) || ...
            any(AbsMagn < xs(:,i) & xs(:,i).^2 < SDFAC^2*diag(Ps(:,:,i)))
        L.logL(i) = -inf;
      end
    end
  end
end
