function genData(name)
%GENDATA Generate data from model using URDME.
%   GENDATA('name') generates synthetic data from the model with
%   name 'name' using URDME. The result is stored as data/['umod'
%   'name'].mat.
%
%   Name      Description
%   ------------------------------------------------------------
%   SIS       SIS-model.
%
%   SIHDRe    As SIHRe, but with added (D)eath.
%
%   Currently, all model parameters are static to this file.

% S. Engblom 2022-12-15 (SIHRe removed)
% S. Engblom 2022-12-08 (SIS added)
% S. Engblom 2022-05-18 (Restructured from generateSIReBranch)
% S. Engblom 2022-05-06

% Models currently generated:
%
% * SIS:
% ------
% The simplest model
%
% S > beta*S/Sigma*I > I
% I > gammaI*I > S
% 
% States: (S,I) = (Susceptible, Infected).
%
% Parameters: (Sigma,beta,gammaI) = (Population, infectivity,
% infectious time).
%
% R0 = beta/gammaI.
%
% * SIHRe:
% --------
% This model is
%
% S > beta*phi*S/Sigma > I
% I > gammaI*F*I > H
% H > gammaH*H > R
% I > gammaI*(1-F)*I > R
% 
% States: (phi,S,I,H,R) = (infectious pressure, Susceptible, Infected,
% Hospitalized, Recovered).
%
% Parameters: (Sigma,beta,F,gammaI,gammaH,theta,rho) = (Population,
% infectivity, severity risk, infectious time, hospitalization
% time, shedding rate, decay rate).
%
% By non-dimensionalization and re-scaling of phi, theta = rho can
% be assumed. Also, R0 = sqrt(beta/gammaI).
%
% * SIHDRe:
% ---------
% A death compartment is added:
%
% S > beta*phi*S/Sigma > I
% I > gammaI*FIH*I > H
% I > gammaI*FID*I > D
% I > gammaI*(1-FIH-FID)*I > R
% H > gammaH*H*FHD > D
% H > gammaH*H*(1-FHD) > R
%
% States: (phi,S,I,H,Dead,R).
%
% Parameters: in addition to the above (FIH, FID, FDH) =
% (severity/hospitalization, severity/fatality, fatality at
% hospital).
%
% The same comments as above applie to phi and to R0.

rng(220506); % reproducible results

switch name
  case 'SIS'
    % load R0 as a time-series
    load data/R0a

    % remaining parameters
    Sigma = 1e5;
    gammaI = 1/7;

    % rates: dynamic
    rates.beta = 'ldata'; % S --> I

    % rates: static
    rates.gammaI = 'gdata'; % I --> S

    % species, transitions and rates
    species = {'S' 'I'};
    r = cell(1,2);
    r{1} = 'S > beta*S*I/vol > I';
    r{2} = 'I > gammaI*I > S';

    % sort it out
    umod = rparse([],r,species,rates,[name '.c']);
    Nspecies = size(umod.N,1);

    % add the rest
    umod.vol = Sigma;
    umod.D = sparse(2,2);
    umod.sd = 1;
    umod.u0 = [Sigma*0.99 Sigma*0.01]';
    umod.tspan = 0:140;

    % dynamic rates
    R0 = ppval(umod.tspan,R0);
    beta = R0*gammaI;

    % static rates
    clear Rates
    Rates.gammaI = gammaI;
    if ~isequal(fieldnames(Rates),umod.private.RateNames(2:end)')
      error('It seems the ordering of rate parameters differ.');
    end

    % convert into Mrates-by-1 matrix:
    GDATA = struct2cell(Rates);
    GDATA = cat(1,GDATA{:});

    % parse and compile
    umod = urdme(umod,'solve',0,'compile',1,'solver','ssa', ...
                 'gdata',GDATA, ...
                 'ldata',zeros(size(umod.ldata,2),1));
    umod.solve = 1;
    umod.parse = 0;
    umod.compile = 0;

    % solve in split-step fashion
    tspan = umod.tspan;
    U = zeros(Nspecies,numel(tspan));
    U(:,1) = umod.u0;
    for i = 2:numel(tspan)
      umod.u0 = U(:,i-1);
      umod.tspan = tspan(i-1:i);
      umod.ldata = beta(i-1);
      umod.seed = randi(intmax);
      umod = urdme(umod);
      U(:,i) = umod.U(:,end);
    end
    umod.tspan = tspan;
    umod.U = U;

    % add dynamic rates as private fields
    umod.private.beta = beta;
    umod.private.R0 = R0;
    
  case 'SIHRe'
    error('Model currently not supported.');
  
  case 'SIHDRe'
    % load R0 as a time-series
    load data/R0a

    % load the severity as a time-series
    load data/F
    % (understood here as the overall IFR)

    % remaining parameters
    Sigma = 1e5;
    gammaI = 1/7;
    gammaH = 1/10;
    FIH = 0.02;
    FHD = 0.10;
    tau = 1; rho = -log(0.5)/tau; % half-time of one day
    theta = rho;

    % rates: dynamic
    rates.beta = 'ldata';
    rates.PHI = 'ldata';

    % fractions: dynamic
    rates.FID = 'ldata'; % I --> D

    % rates: static
    rates.gammaI = 'gdata'; % I -->
    rates.gammaH = 'gdata'; % H -->
    rates.rho = 'gdata'; % (handled manually)

    % fractions: static
    rates.FIH = 'gdata'; % I --> H
    rates.FHD = 'gdata'; % H --> D

    % species, transitions and rates
    species = {'phi' 'S' 'I' 'H' 'D' 'R'};
    r = cell(1,6);
    r{1} = 'S > beta*PHI*S/vol > I'; % note: PHI (double) or phi (integer)
    r{2} = 'I > gammaI*FIH*I > H';
    r{3} = 'I > gammaI*FID*I > D';
    r{4} = 'I > gammaI*(1-FIH-FID)*I > R';
    r{5} = 'H > gammaH*FHD*H > D';
    r{6} = 'H > gammaH*(1-FHD)*H > R';

    % sort it out
    umod = rparse([],r,species,rates,[name '.c']);
    Nspecies = size(umod.N,1);

    % add the rest
    umod.vol = Sigma;
    umod.D = sparse(6,6);
    umod.sd = 1;
    umod.u0 = [0 Sigma*0.99 Sigma*0.01 0 0 0]';
    umod.u0(1) = umod.u0(3)*theta/rho; % (stationary phi)
    umod.tspan = 0:140;

    % dynamic rates
    R0 = ppval(umod.tspan,R0);
    beta = R0.^2*gammaI;
    IFR = ppval(umod.tspan,F);
    FID = IFR-FIH*FHD;
    % (since the total IFR = FID+FIH*FHD)

    % static rates
    clear Rates
    Rates.gammaI = gammaI;
    Rates.gammaH = gammaH;
    Rates.rho = rho;
    Rates.FIH = FIH;
    Rates.FHD = FHD;
    if ~isequal(fieldnames(Rates),umod.private.RateNames(4:end)')
      error('It seems the ordering of rate parameters differ.');
    end

    % convert into Mrates-by-1 matrix:
    GDATA = struct2cell(Rates);
    GDATA = cat(1,GDATA{:});
    % (rho handled manually)

    % parse and compile
    umod = urdme(umod,'solve',0,'compile',1,'solver','ssa', ...
                 'gdata',GDATA, ...
                 'ldata',zeros(size(umod.ldata,2),1));
    umod.solve = 1;
    umod.parse = 0;
    umod.compile = 0;

    % solve in split-step fashion
    tspan = umod.tspan;
    U = zeros(Nspecies,numel(tspan));
    U(:,1) = umod.u0;
    PHI = zeros(1,numel(tspan));
    PHI(1) = umod.u0(1);
    for i = 2:numel(tspan)
      umod.u0 = U(:,i-1);
      umod.tspan = tspan(i-1:i);
      umod.ldata = [beta(i-1) PHI(i-1) FID(i-1)]';
      umod.seed = randi(intmax);
      umod = urdme(umod);
      U(:,i) = umod.U(:,end);

      % shedding
      shed = theta*U(3,i-1);
      % exponential exact integrator for linear decay rho
      PHI(i) = PHI(i-1)*exp(-rho)-shed/rho*expm1(-rho);

      % put phi where it belongs
      U(1,i) = PHI(i);
    end
    umod.tspan = tspan;
    umod.U = U;

    % add dynamic rates as private fields
    umod.private.beta = beta;
    umod.private.FID = FID;
    umod.private.R0 = R0;
    umod.private.IFR = IFR;

  otherwise, error('Unknown model name.');
end

% save to file
save(['data/umod_' name '.mat'],'umod');

% ----------------------------------------------------------------------
function [x,y] = l_getxy(ax)
%L_GETXY Gets a series of coordinates (X,Y).
%   [X,Y] = L_GETXY(AX) sets the axis AX and collects mouse cursor
%   clicks. Exit by pressing space.

if nargin == 0, ax = [0 1 0 1]; end
clf, axis(ax); hold on, grid on, set(gca,'xtick',ax(1):7:ax(2));
n = 0;
x = zeros(1,0); y = zeros(1,0);
while true
  [xx,yy,button] = ginput(1);
  if button == ' '; break; end % end with space
  n = n+1;
  x(n) = xx;
  y(n) = yy;
  plot(xx,yy,'.k');
  drawnow,
end
% ----------------------------------------------------------------------
