%testDynOpt Test of dynamic beta.

% J. Evaeus 2022-01-12 (Adapted to EpiID framework)

% S. Engblom 2022-12-14

if ~exist('windowlength','var')
  windowlength = 80; % What is reasonable here?
  %ORIGINAL : 80
end

ntime = 365;
maxfunceval = 2700000;


if ~exist('verb','var')
  verb = false;
end

startday = 1;
endday = 60;

endday_ = startday;

% Tweaked wbeta to make posterior look OK. 
wbeta=10000;%300000;
steplength= 5;%20;
%ORIGINAL: 5

% posterior

postrates = getPost('SIHDRe','SMC');

% load filter data

load data/umod_SIHDRe

tspan = umod.tspan;
Ntime = numel(tspan);
Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)

% define data and filter periods
ixdata = startday:endday+ntime-1;

ixfilter = ixdata;

% specify observation model
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
Nstates = 5; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 

% Initial states. For now, simply initialize on true state:
x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
P0 = diag(x0+1);

[Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);

S = L.Scov;

F = cell(Ntime,1);
for m = 1:Ntime
  KF_ = KF_func(postrates,Nstates,m);
  F{m} = KF_.F;
end

H = DF.H;
betaIdx = false(obsrates.Nstates-1);
betaIdx(2,1) = true; % element of F where beta is found

beta0 = 0.1*ones(1,ntime);

if verb
  display = 'iter-detailed';
else
  display = 'off';
end
options = optimoptions(@fmincon,'MaxFunctionEvaluations',maxfunceval,...
                       'MaxIterations',6000,'Display',display,...
                       'OptimalityTolerance',2e-5);

[x0_post,betaOpt,J,misfit] = DynOpt(squeeze(Ydata),F,H,betaIdx,wbeta,S,steplength, ...
                                  windowlength,x0,beta0,options);


%plot(betaOpt)
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3, ...
                                                  1));

%Variance of true beta, used for noise
var_ubeta = std(ubeta);

%Noise for beta has standard deviation 1/5 of standard deviation for true
%beta
var_noise = var_ubeta/5;

%%% TESTING! %%%

%
test_mode = 1; % 1: Use output as input, 2: vary beta, 3: vary beta based on starting beta
               % 4: Change beta_0
iters = 10;
noise = var_noise*randn(length(betaOpt),1);
all_betaopt = zeros(length(betaOpt), iters+1);
all_betaopt(:, 1) = betaOpt;
if test_mode == 3
    orig_beta = postrates.beta;
end

for i = 1:iters
    i % To see which iteration we are on

    %Use output as input and run again to get error estimation of
    %prediction, or change beta, or change beta0
    if test_mode == 1
        postrates.beta = betaOpt.' + noise;
        postrates.beta = max(postrates.beta, 0);
    elseif test_mode == 2
        postrates.beta = abs(postrates.beta + noise);
    elseif test_mode == 3
        postrates.beta = abs(orig_beta + noise);
    elseif test_mode == 4
        beta0(1:length(betaOpt)) = abs(betaOpt.' + noise);
    end
     
    [Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);
    
    S = L.Scov;
    
    F = cell(Ntime,1);
    for m = 1:Ntime
      KF_ = KF_func(postrates,Nstates,m);
      F{m} = KF_.F;
    end
    [x0_post,betaOpt,J,misfit] = DynOpt(squeeze(Ydata),F,H,betaIdx,wbeta,S,steplength, ...
                                  windowlength,x0,beta0,options);
    all_betaopt(:,i+1) = betaOpt;
    %plot(betaOpt)
    noise = randn(length(betaOpt),1);
end

means = zeros(length(betaOpt),1);
standard_dev = zeros(length(betaOpt),1);

for j = 1:length(betaOpt)
    means(j) = mean(all_betaopt(j,:));
    standard_dev(j) = std(all_betaopt(j,:));
end

%Plot mean and std. div.
lim1 = means + 2*standard_dev;
lim2 = means - 2*standard_dev;
x = 1:141;
betw1 = [x.', lim1];
betw2 = [x.', lim2];
combine = [betw1; flipud(betw2)];
figure(1),hold on
gray = [.7 .7 .7];
fill(combine(:,1), combine(:,2), gray, 'DisplayName', 'DynOpt')
plot(x, means, 'HandleVisibility', 'off')

%%% End TESTING %%%

plot(x, ubeta, 'DisplayName', 'True beta')
legend
title("steplen: " + steplength + ", Winlen: "+ windowlength + ", Iters: " + iters)

return;

function y = KF_func(postrates, Nstates, index)
postrates_ = postrates;
postrates_.beta = postrates.beta(index);
postrates_.FID = postrates.FID(index);
Sys = getSyst('SIHDRe',postrates_);
Sys.Q0 = ones(Nstates,1);
Sys.qdiag = [0.05^2];
y = getFilt(Sys);
end