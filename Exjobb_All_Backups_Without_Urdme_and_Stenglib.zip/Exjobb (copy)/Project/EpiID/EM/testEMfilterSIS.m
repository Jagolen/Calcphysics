%testEMfilterSIS Test of EM-filter/inference and SIS-model.

% S. Engblom 2022-12-08

%% (0) *** model name:
%name = 'SIS'
name = 'SIHDRe'

% load synthetic data
load(['data/umod_' name]);

%% (1) parse the rates of the URDME model: ldata dynamic, gdata static
ixdynrates = strcmp(umod.private.RateVals,'ldata');
ixrates = strcmp(umod.private.RateVals,'gdata');
RateNames = umod.private.RateNames;
rates = cell2struct(num2cell(umod.gdata)', ...
                    RateNames(ixrates),2);
% copy all dynamic rates
dynrates = struct;
for i = find(ixdynrates)
  try
    dynrates.(RateNames{i}) = umod.private.(RateNames{i});
  catch
    % meant to silently ignore PHI from now on:
    ixdynrates(i) = false;
    continue;
  end
end
% *** correction factor = S/Sigma ~ 1
ixS = find(ismember(umod.private.Species,'S'));
dynrates.beta = umod.private.beta.*umod.U(ixS,:)/umod.vol;

%% (2) build corresponding filter

% set zero rates for all dynamic rates
for f = RateNames(ixdynrates)
  rates.(f{1}) = 0;
end
Sys = getSyst(name,rates);

% params array used to build dynamic filter:
params = struct2cell(dynrates); % *** check ordering
params = cat(1,params{:});
% (Sys can now be update wrt the dynamic rates using the pJacDyn-field
% together with the params-matrix)

%% (3) connect with data available for identification

% convention: "ix" refers to URDME struct, "jx" to the Kalman filter
switch name
  case 'SIS'
    ixdata = find(ismember(umod.private.Species,'I'));
    jxdata = find(ismember(Sys.Species,'I'));
    % inspected in plots:
    ixplot = ixdata;
    jxplot = jxdata;
  case 'SIHDRe'
    ixdata = find(ismember(umod.private.Species,{'H' 'D'}));
    jxdata = find(ismember(Sys.Species,{'H' 'D'}));
    ixplot = find(ismember(umod.private.Species,'I'));
    jxplot = find(ismember(Sys.Species,'I'));
end

% recorded data
tspan = umod.tspan;
Ntime = numel(tspan);
Data = umod.U(ixdata,:);

% build datafilter
obsrates.states = num2cell(jxdata);
obsrates.weights = num2cell(ones(size(jxdata)));
obsrates.Nstates = size(Sys.N,1);
% $$$ obsrates.R0 = 10*ones(numel(obsrates.states),1);
% $$$ obsrates.rdiag = [0.1^2];
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.05^2];
DF = getObs(obsrates);

%% (4) initial state estimation
%KF = l_KF(Sys,params,1);
%[x0,P0] = initFilt(Data(:,1),KF,DF);
% *** for now:
[jx,ix] = ismember(Sys.Species,umod.private.Species);
x0 = umod.U(ix(jx),1);
P0 = 10+diag(x0).^2;

%% (5) dynamic estimation
[x,P,L] = kalman(x0,P0,@l_KF,Data(:,2:end),DF,'rts',Sys,params);

% posterior (including estimated initial state)
xx = [repmat(x0,1,1,3) x];
PP = cat(3,repmat(P0,1,1,1,3),P);

%% (6) visualization
figure(1), clf,
nm = {'URDME Data' 'Kalman pred' 'Kalman post','RTS'};
pt = {'ko-' 'bs-' 'rx-' 'g.-'};
U = umod.U(:,1:Ntime);
plot(tspan,U(ixplot,:),pt{1},'DisplayName',nm{1}); hold on
for k = 1:3
  h = plot(tspan,xx(jxplot,:,k),pt{k+1},'DisplayName',nm{k+1});
  std_ = permute(sqrt(PP(jxplot,jxplot,:,k)),[1 3 2]);
  errorshade(tspan,xx(jxplot,:,k)-std_,xx(jxplot,:,k)+std_,get(h,'Color'));
end
legend

% $$$ % compare with raw unfiltered prediction:
% $$$ x_ = [x0 zeros(size(x,1),Ntime-1)];
% $$$ for i = 1:Ntime-1
% $$$   KF = l_KF(Sys,params,i);
% $$$   x_(:,i+1) = KF.F*x_(:,i);
% $$$ end
% $$$ hold on,
% $$$ plot(tspan,x_(jxplot,:),'m.-','DisplayName','Unfiltered pred');

% ----------------------------------------------------------------------
function KF = l_KF(Sys,params,i)
%L_KF Dynamic Kalman filter with parameter dependence.

% replace parameters (linearly) and rebuild filter
Sys.pJac = Sys.pJac+reshape(Sys.pJacDyn*params(:,i),size(Sys.pJac));
KF = getFilt(Sys);

end
% ----------------------------------------------------------------------
