function [x00,theta,J,misfit,beta_mpc,ix_mpc] = ...
      DynOpt_beta_and_FID_win_and_wbeta_wfid_change(y,F,H,betaIdx,FIDIdx1,FIDIdx2,wbeta,wfid,S,steplength,windowlength,x0, ...
             theta0,options)
  
%DynOpt Dynamic beta and FID optimization using an MPC-setup A cost
% function (DynOpt_cost_beta_and_FID) is used to optimized beta and FID.

%MPCLOOP_BETA solves dynamic beta optimization using an MPC-setup
%   [x0,beta,J,misfit] = MPCLOOP_BETA(y,F,H,betaIdx,wbeta,wy,steplength,
%   windowlength,x0,beta0) solves the optimization problem of minimizing
%   J = sum((y-yH).^2.*wy)) + wbeta*diff(beta).^2, where y is a measured
%   signal and yH is the output of the state space model defined by F and
%   H, with time dependent beta at the element of F defined by betaIdx (see
%   also BETACOST). The windowlength and steplength define the optimization
%   horizon and step length of the mpc. The inputs x0 and beta0 are initial
%   guesses for the optimization. The outputs x0 and beta are the optimal
%   values, while J and misfit are the values of the full cost function and
%   the part of the cost corresponding to the misfit (i.e. excluding the
%   regularization penalty.

% J Evaeus 2023-01-12 (Minor revisions)

% S. Engblom 2022-12-14 (Major revision, based on mpcloop_beta_S)

% H. Runvik 2021-04-12

if nargin < 13
  options = optimoptions(@fmincon,'MaxFunctionEvaluations',1700000,...
                         'MaxIterations',6000,'Display','iter-detailed');
end

nstate = size(F{1},1);
ntime = size(y,2);

slab = 1:ntime; % does it make sense to introduce "slabs" in this way? 

nstart = [1:steplength:ntime-windowlength ntime-windowlength+1];
nsteps = numel(nstart);
theta = zeros(2,ntime);

betastruct.idx=betaIdx;
FIDstruct1.idx=FIDIdx1;
FIDstruct2.idx=FIDIdx2;

beta_mpc = zeros(nsteps,windowlength);
ix_mpc = zeros(nsteps,windowlength);

%Used Rates
gamma_i = 1/7;
FIH = 0.02;

for k = 1:nsteps
    k
  if k == 1
    y_loc = y(:,nstart(k):nstart(k)+windowlength-1);
    theta0_loc = theta0(:,1:windowlength);
    ub = 5*theta0_loc;
    lb = 0*theta0_loc;
    slab_loc = slab(nstart(k):nstart(k)+windowlength-1);

    %Find optimal beta and FID of window using cost function.
    thetaFunc = @(u)DynOpt_cost_beta_and_FID(u,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
    [thetatemp,~,exitflag]=fmincon(thetaFunc,[theta0_loc],[],[],[],[],...
                                  lb,...
                                  ub,[],options);
    if exitflag ~=1 && exitflag ~=2
      disp('Convergence problem')
    end
    [cost_fun_val, betapart, fidpart, L] = DynOpt_cost_beta_and_FID(thetatemp,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
    cost_fun_val = cost_fun_val*1e4;
    while true
        if 0.1*cost_fun_val > betapart && 0.1*cost_fun_val > fidpart
            break
        end
        if 0.1*cost_fun_val < betapart
            wbeta = 0.8*wbeta
        end
        if 0.1*cost_fun_val < fidpart
            wfid = 0.8*wfid
        end
        thetaFunc = @(u)DynOpt_cost_beta_and_FID(u,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
        [thetatemp,~,exitflag]=fmincon(thetaFunc,[theta0_loc],[],[],[],[],...
                                      lb,...
                                      ub,[],options);    
        [cost_fun_val, betapart, fidpart, L] = DynOpt_cost_beta_and_FID(thetatemp,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
        cost_fun_val = cost_fun_val*1e4
        betapart
        fidpart
    end
    wbeta
    wfid
    x00=x0';

  else
    options.InitBarrierParam=1e-4;
    y_loc = y(:,nstart(k):nstart(k)+windowlength-1);
    slab_loc = slab(nstart(k):nstart(k)+windowlength-1);
    ub = 5*theta0_loc;
    ub(:,1) = thetaPrev;
    lb = 0*theta0_loc;
    lb(:,1) = thetaPrev;
    %A = zeros(2,windowlength*2);
    %A(1,1) = 1;
    %A(2, windowlength+1) = 1;
    thetaFunc = @(u)DynOpt_cost_beta_and_FID(u,y_loc,F,H,betaIdx,FIDIdx1,FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
    [thetatemp,~,exitflag]=fmincon(thetaFunc,theta0_loc,[],[],[],...
                                  [],lb,ub,[],...
                                  options);
    if exitflag ~=1 && exitflag ~=2
      disp('Convergence problem')
    end

    [cost_fun_val, betapart, fidpart, L] = DynOpt_cost_beta_and_FID(thetatemp,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
    cost_fun_val = cost_fun_val*1e4;
    while true
        if 0.1*cost_fun_val > betapart && 0.1*cost_fun_val > fidpart
            break
        end
        if 0.1*cost_fun_val < betapart
            wbeta = 0.8*wbeta
        end
        if 0.1*cost_fun_val < fidpart
            wfid = 0.8*wfid
        end
        thetaFunc = @(u)DynOpt_cost_beta_and_FID(u,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
        [thetatemp,~,exitflag]=fmincon(thetaFunc,[theta0_loc],[],[],[],[],...
                                      lb,...
                                      ub,[],options);    
        [cost_fun_val, betapart, fidpart, L] = DynOpt_cost_beta_and_FID(thetatemp,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
        cost_fun_val = cost_fun_val*1e4
        betapart
        fidpart
    end
    wbeta
    wfid
    x00=x0';


  end
    
  if k == 1
    theta(:,nstart(k):nstart(k)+steplength-1) = ...
        thetatemp(:,1:steplength);
    betastruct.vals=thetatemp(1,1:steplength)';
    FIDstruct1.vals=gamma_i.*thetatemp(2,1:steplength)';
    FIDstruct2.vals=gamma_i.*(1-FIH-thetatemp(2,1:steplength))';
    xSim = LPVsim_slabs_modified(F,x0,[betastruct FIDstruct1 FIDstruct2],slab_loc);
    x0 = xSim(:,end);
    thetaPrev = thetatemp(:,steplength+1);
    theta0_loc = [thetatemp(:,steplength+1:end)...
                 theta0(:,windowlength+1:windowlength+steplength)];
    %beta_mpc(k,:) = betatemp(1:end);
    %ix_mpc(k,:) = 1:windowlength;
  elseif k<nsteps
    theta(:,nstart(k):nstart(k+1)-1)...
        = thetatemp(:,1:nstart(k+1)-nstart(k));
    betastruct.vals = thetatemp(1,1:nstart(k+1)-nstart(k))';
    FIDstruct1.vals = gamma_i.*thetatemp(2,1:nstart(k+1)-nstart(k))';
    FIDstruct2.vals = gamma_i.*(1-FIH-thetatemp(2,1:nstart(k+1)-nstart(k))');
    xSim = LPVsim_slabs_modified(F,x0,[betastruct FIDstruct1 FIDstruct2],slab_loc);
    x0 = xSim(:,end);
    thetaPrev = thetatemp(:,nstart(k+1)-nstart(k)+1);
    theta0_loc = [thetatemp(:,nstart(k+1)-nstart(k)+1:end)...
                 theta0(:,nstart(k)+windowlength:nstart(k+1)+windowlength-1)];
    %beta_mpc(k,:)=betatemp;
    %ix_mpc(k,:)=nstart(k):nstart(k)+windowlength-1;
  else
    theta(:,nstart(k):end) = thetatemp;
    windowlength = windowlength-steplength;
    betastruct.vals = thetatemp(1,1:steplength)';
    FIDstruct1.vals = gamma_i.*thetatemp(2,1:steplength)';
    FIDstruct2.vals = gamma_i.*(1-FIH-thetatemp(2,1:steplength)');
    xSim = LPVsim_slabs_modified(F,x0,[betastruct FIDstruct1 FIDstruct2],slab_loc);
    x0 = xSim(:,end);
    thetaPrev = thetatemp(:,steplength+1);
    theta0_loc = [thetatemp(:,steplength+1:end)];
    %beta_mpc(k,:)=betatemp;
    %ix_mpc(k,:)=nstart(k):nstart(k)+windowlength-1;
  end
end

% Test of shrinking window
% while windowlength >= steplength
%     options.InitBarrierParam=1e-4;
%     y_loc = y(:,end-windowlength+1:end);
%     slab_loc = slab(end-windowlength+1:end);
%     ub = 5*theta0_loc;
%     ub(:,1) = thetaPrev;
%     lb = 0*theta0_loc;
%     lb(:,1) = thetaPrev;
% 
%     thetaFunc = @(u)DynOpt_cost_beta_and_FID(u,y_loc,F,H,betaIdx,FIDIdx1,FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
%     [thetatemp,~,exitflag]=fmincon(thetaFunc,theta0_loc,[],[],[],...
%                                   [],lb,ub,[],...
%                                   options);
%     if exitflag ~=1 && exitflag ~=2
%       disp('Convergence problem')
%     end
% 
%     [cost_fun_val, betapart, fidpart, L] = DynOpt_cost_beta_and_FID(thetatemp,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
%     cost_fun_val = cost_fun_val*1e4;
%     while true
%         if 0.15*cost_fun_val > betapart && 0.15*cost_fun_val > fidpart
%             break
%         end
%         if 0.15*cost_fun_val < betapart
%             wbeta = 0.8*wbeta
%         end
%         if 0.15*cost_fun_val < fidpart
%             wfid = 0.8*wfid
%         end
%         thetaFunc = @(u)DynOpt_cost_beta_and_FID(u,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
%         [thetatemp,~,exitflag]=fmincon(thetaFunc,[theta0_loc],[],[],[],[],...
%                                       lb,...
%                                       ub,[],options);    
%         [cost_fun_val, betapart, fidpart, L] = DynOpt_cost_beta_and_FID(thetatemp,y_loc,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab_loc,S(:,:,nstart(k):nstart(k)+windowlength-1),x0);
%         cost_fun_val = cost_fun_val*1e4
%         betapart
%         fidpart
%     end
%     wbeta
%     wfid
%     x00=x0';
% 
% 
%     theta(:,end-windowlength+1:end) = thetatemp;
%     windowlength = windowlength - steplength
%     if (steplength + 1) <= length(thetatemp(1,:))
%         betastruct.vals = thetatemp(1,1:steplength)';
%         FIDstruct1.vals = gamma_i.*thetatemp(2,1:steplength)';
%         FIDstruct2.vals = gamma_i.*(1-FIH-thetatemp(2,1:steplength)');
%         xSim = LPVsim_slabs_modified(F,x0,[betastruct FIDstruct1 FIDstruct2],slab_loc);
%         x0 = xSim(:,end);
%         thetaPrev = thetatemp(:,steplength+1);
%         theta0_loc = [thetatemp(:,steplength+1:end)];
%     end
% end



x00=x00';
[J,beta_part,fid_part,misfit] = DynOpt_cost_beta_and_FID(theta,y,F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid,slab,S,x00);
