%testDynOpt_test_of_eod_effects Test of eod effects
% Return plot showing changes between first optimization and final result,
% for as many windows as possible, i.e. for the whole timespan except the
% final windowlengths worth, since there is no comparison to be made there.

% J. Evaeus 2022-01-12 (Adapted to EpiID framework)

% S. Engblom 2022-12-14

if ~exist('windowlength','var')
  windowlength = 80; % What is reasonable here?
  %ORIGINAL : 80
end

ntime = 365;
maxfunceval = 2700000;


if ~exist('verb','var')
  verb = false;
end

startday = 1;
endday = 60;

endday_ = startday;

% Tweaked wbeta to make posterior look OK. 
wbeta=10000;%300000;
steplength= 5;%20;
%ORIGINAL: 5

% posterior

postrates = getPost('SIHDRe','SMC');

% load filter data

load data/umod_SIHDRe

tspan = umod.tspan;
Ntime = numel(tspan);
Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)

% define data and filter periods
ixdata = startday:endday+ntime-1;

ixfilter = ixdata;

% specify observation model
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
Nstates = 5; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 

% Initial states. For now, simply initialize on true state:
x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
P0 = diag(x0+1);

[Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);

S = L.Scov;

F = cell(Ntime,1);
for m = 1:Ntime
  KF_ = KF_func(postrates,Nstates,m);
  F{m} = KF_.F;
end

H = DF.H;
betaIdx = false(obsrates.Nstates-1);
betaIdx(2,1) = true; % element of F where beta is found

beta0 = 0.1*ones(1,ntime);

if verb
  display = 'iter-detailed';
else
  display = 'off';
end
options = optimoptions(@fmincon,'MaxFunctionEvaluations',maxfunceval,...
                       'MaxIterations',6000,'Display',display,...
                       'OptimalityTolerance',2e-5);


%%% START TESTING %%%
[x0_post,betaOpt,beta_var,J,misfit] = DynOpt_eod_effects(squeeze(Ydata),F,H,betaIdx,wbeta,S,steplength, ...
                                  windowlength,x0,beta0,options);


%plot(betaOpt)
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3, ...
                                                  1));
%beta_var holds every window optimized, we compare those to the final
%result, for every window that has a value both in the beginning and end of
%windows, i.e. the timespan except for the final window length, since there
%is no comparison to be made there
difference = [];
step = 1;
beta_var_loc = 1;

% Store difference between windows and final result, which later will be
% averaged.
while step < (length(betaOpt) - windowlength)
    difference = [difference; beta_var(beta_var_loc,:) - betaOpt(step:step+windowlength-1)];
    beta_var_loc = beta_var_loc + 1
    step = step + steplength
end

% find mean and std div depending on where in the window we are, i.e. see
% the effects when a value is at position 5 in a window compared to the
% final result etc., for every location in the window.
% The mean will therefore be of size windowlength.
means = zeros(windowlength,1);
standard_dev = zeros(windowlength,1);
difference = difference';
for j = 1:windowlength
    means(j) = mean(difference(j,:));
    standard_dev(j) = std(difference(j,:));
end

%Plot mean and std. div.
lim1 = means + 2*standard_dev;
lim2 = means - 2*standard_dev;
x = 1:windowlength;
betw1 = [x.', lim1];
betw2 = [x.', lim2];
combine = [betw1; flipud(betw2)];
figure(1),
hold on
gray = [.7 .7 .7];
fill(combine(:,1), combine(:,2), gray, 'DisplayName', 'Variance of changes')
plot(x, means, 'DisplayName', 'Mean difference')
legend
title("steplen: " + steplength + ", Winlen: "+ windowlength)
hold off

%%% End TESTING %%%
return;

function y = KF_func(postrates, Nstates, index)
postrates_ = postrates;
postrates_.beta = postrates.beta(index);
postrates_.FID = postrates.FID(index);
Sys = getSyst('SIHDRe',postrates_);
Sys.Q0 = ones(Nstates,1);
Sys.qdiag = [0.05^2];
y = getFilt(Sys);
end