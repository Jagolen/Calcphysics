iters = 5;
all_I = zeros(iters, 141);
all_H = zeros(iters, 141);
all_D = zeros(iters, 141);

for i = 1:iters
    genData('SIHDRe')
    load DynOpt/data/umod_SIHDRe
    all_I(i,:) = umod.U(3,:);
    all_H(i,:) = umod.U(4,:);
    all_D(i,:) = umod.U(5,:);
end

x = 1:141;

figure(1)
subplot(3,1,1)
hold on
for i = 1:iters
    plot(x,all_I(i,:),'r')
end
xlabel("T")
ylabel("Population")
title("Infected")

subplot(3,1,2)
hold on
for i = 1:iters
    plot(x,all_H(i,:),'b')
end
xlabel("T")
ylabel("Population")
title("Hospitalized")

subplot(3,1,3)
hold on
for i = 1:iters
    plot(x,all_D(i,:),'g')
end
xlabel("T")
ylabel("Population")
title("Deaths")
