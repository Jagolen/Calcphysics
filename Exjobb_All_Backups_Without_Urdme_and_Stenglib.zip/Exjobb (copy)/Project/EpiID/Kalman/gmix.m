function [xxa,PPa] = gmix(ww,xx,PP)
%GMIX Gaussian mixture.
%   [xxa,PPa] = GMIX(ww,xx,PP) computes the weighted estimate
%   (xxa,PPa) from the weights ww and individual Gaussian estimates
%   (xx,PP). No error-checking is done.

% S. Engblom 2022-05-19

xxa = tprod(xx,ww,[1 2 -1],[-1]);
PPa = tprod(PP+tprod(xx-xxa,xx-xxa,[1 3 4],[2 3 4]),ww,[1 2 3 -1],[-1]);
