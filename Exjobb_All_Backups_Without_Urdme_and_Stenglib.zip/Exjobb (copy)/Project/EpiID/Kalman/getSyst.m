function Sys = getSyst(name,rates,ver)
%GETSYST system matrices for model.
%   SYS = GETSYST('name',RATES) assembles, for the model with name
%   'name' and for rate parameter struct RATES, a struct SYS
%   containing a propensity Jacobian pJac, a stoichiometric matrix N,
%   and a list of cumulative/incidence/deterministic/removed states
%   CStates/IStates/DStates/Astates. The output is intended to be used
%   as input to getFILT.
%
%   SYS.pJac is Mtransitions-by-Nstates and pJac(i,j) defines the
%   linear rate of the ith transition with respect to the jth
%   compartment.
%
%   SYS.N is Nstates-by-Mtransitions and N(:,i) is the increment to
%   the state vector of the ith stransitions.
%
%   CStates, IStates, DStates, and AStates are arrays of indices which
%   define properties of the corresponding states in the following
%   way:
%
%   -SYS.CStates: states that will get cumulative counterparts in
%   order to, e.g., allow for comparison with measured data.
%
%   -SYS.IStates: states that similarly will get incidence
%   counterparts.
%
%   -SYS.DStates: deterministic states which is treated differently
%   with respect to process noise.
%
%   -SYS.AStates: states that will be removed in the final model. The
%   purpose of including states that will be removed later is to
%   represent the transitions from other states into these sink states
%   in a convenient way.
%
%   See also getFILT.

% S. Engblom 2022-12-14 (Major revision, new format) 
% S. Engblom 2022-12-08 (added SIS)
% S. Engblom 2022-05-18 (mild generalization)
% S. Engblom 2022-05-07 (Based on code getC19syst)

% S. Engblom 2021-03-03 (Revision, optional CStates/IStates)
% S. Engblom 2020-10-22 (Revision, slab)
% H. Runvik 2020-10-01 (Revision, adding P state)
% H. Runvik 2020-09-14

% silent: version (ver = 2 is deprecated)
if nargin < 3, ver = 1; end

if ver == 1
switch name
  case 'SIS'
    beta = rates.beta;
    gammaI = rates.gammaI;

    Sys.Species = {'S' 'I'};
    % Transitions: {'S > beta*I > I' 'I > gammaI*I > S'}
    Sys.pJac = [0 beta; ...
                0 gammaI];
    % sparse format for derivative of Jacobian wrt dynamic parameters
    pJacDyn_ = sparse(size(Sys.pJac,1),size(Sys.pJac,2));
    pJacDyn_(1,2) = 1; % beta
    Sys.pJacDyn = pJacDyn_(:);
    Sys.N = [-1  1; ...
              1 -1];

    % no deterministic states in this model
    Sys.DStates = [];

    % optional cumulative/incidence variables:
    if isfield(rates,'CStates')
      Sys.CStates = rates.CStates; % compartments with added cumulative state
    else
      Sys.CStates = [];
    end
    if isfield(rates,'IStates')
      Sys.IStates = rates.IStates; % compartment with added incidence state
    else
      Sys.IStates = [];
    end
    % no states to remove in this model
    Sys.AStates = [];

  case 'SIHDRe'
    beta = rates.beta;
    FID = rates.FID;
    gammaI = rates.gammaI;
    gammaH = rates.gammaH;
    FIH = rates.FIH;
    FHD = rates.FHD;
    rho = rates.rho;

    % this scaling uses that theta = rho:
    erho = -expm1(-rho); % (skip division by rho here)

    Sys.Species = {'phi' 'I' 'H' 'D' 'R'};
    % Transitions: {'@ > beta*phi > I' 'I > gammaI*FIH*I > H' ...
    %   'I > gammaI*FID*I > D' 'I > gammaI*(1-FIH-FID)*I > R'
    %   'H > gammaH*FHD*H > D' 'H > gammaH*(1-FHD)*H > R'
    %               '@ > rho*I > phi' 'phi > rho*phi > @'}
    % or for phi
    %   phi_{k+1} = phi_k-erho*phi_k+erho*I
    Sys.pJac = [ ...
        beta      0                    0              0  0; ...
        0         gammaI*FIH           0              0  0; ...
        0         gammaI*FID           0              0  0; ...
        0         gammaI*(1-FIH-FID)   0              0  0; ...
        0         0                    gammaH*FHD     0  0; ...
        0         0                    gammaH*(1-FHD) 0  0; ...
        0         erho                 0              0  0; ...
        erho      0                    0              0  0];
    % sparse format for derivative of Jacobian wrt dynamic parameters
    pJacDyn_ = sparse(size(Sys.pJac,1),size(Sys.pJac,2));
    pJacDyn_(1,1) = 1; % beta
    Sys.pJacDyn = pJacDyn_(:);
    pJacDyn_(1,1) = 0; % (remove beta)
    pJacDyn_(3,2) = gammaI; % FID
    pJacDyn_(4,2) = -gammaI; % FID
    Sys.pJacDyn = [Sys.pJacDyn pJacDyn_(:)];
    Sys.N = [0   0   0   0   0   0   1  -1; ...
             1  -1  -1  -1   0   0   0   0; ...
             0   1   0   0  -1  -1   0   0; ...
             0   0   1   0   1   0   0   0; ...
             0   0   0   1   0   1   0   0];

    Sys.DStates = 1;  % deterministic compartments
    Sys.AStates = []; % states that should be removed

    % optional cumulative/incidence variables:
    if isfield(rates,'CStates')
      Sys.CStates = rates.CStates; % compartments with added cumulative state
    else
      Sys.CStates = [];
    end
    if isfield(rates,'IStates')
      Sys.IStates = rates.IStates; % compartment with added incidence state
    else
      Sys.IStates = [];
    end
  otherwise, error('Unknown model name.');
end

% defaults
Sys.Q0 = ones(size(Sys.N,1),1);
Sys.qdiag = 0.05^2;

return;
end % (ver == 1)

% deprecated ver = 2:
switch name
  case 'SIS'
    error('Not supported.');
  case 'SIHRe'
    beta = rates.beta;
    F = rates.F;
    gammaI = rates.gammaI;
    gammaH = rates.gammaH;
    rho = rates.rho;

    % this scaling uses that theta = rho:
    erho = -expm1(-rho); % (skip division by rho here)

    % States: [phi I H R]
    Sys.transMat = [ ...
        0 beta 0        0; ...
        0 0    gammaI*F gammaI*(1-F); ...
        0 0    0        gammaH; ...
        0 0    0        0];
    Sys.dMat = [exp(-rho) erho 0 0];

    % cannot easily be changed:
    Sys.DStates = 1;  % deterministic compartments
    Sys.AStates = []; % states that should be removed

    % optional cumulative/incidence variables:
    if isfield(rates,'CStates')
      Sys.CStates = rates.CStates; % compartments with added cumulative state
    else
      Sys.CStates = [];
    end
    if isfield(rates,'IStates')
      Sys.IStates = rates.IStates; % compartment with added incidence state
    else
      Sys.IStates = [];
    end
  case 'SIHDRe'
    beta = rates.beta;
    FID = rates.FID;
    gammaI = rates.gammaI;
    gammaH = rates.gammaH;
    FIH = rates.FIH;
    FHD = rates.FHD;
    rho = rates.rho;

    % this scaling uses that theta = rho:
    erho = -expm1(-rho); % (skip division by rho here)

    % States: [phi I H D R]
    Sys.transMat = [ ...
        0 beta 0          0             0; ...
        0 0    gammaI*FIH gammaI*FID    gammaI*(1-FIH-FID); ...
        0 0    0          gammaH*FHD    gammaH*(1-FHD); ...
        0 0    0          0             0; ...
        0 0    0          0             0];
    Sys.dMat = [exp(-rho) erho 0 0 0];

    Sys.DStates = 1;  % deterministic compartments
    Sys.AStates = []; % states that should be removed

    % optional cumulative/incidence variables:
    if isfield(rates,'CStates')
      Sys.CStates = rates.CStates; % compartments with added cumulative state
    else
      Sys.CStates = [];
    end
    if isfield(rates,'IStates')
      Sys.IStates = rates.IStates; % compartment with added incidence state
    else
      Sys.IStates = [];
    end
  otherwise, error('Unknown model name.');
end

% defaults
Sys.Q0 = ones(size(Sys.transMat,1),1);
Sys.qdiag = 0.05^2;

% Older help-text for ver = 2:

%   SYS = GETSYST('name',RATES) assembles, for model with name 'name'
%   and for rate parameter struct RATES, a struct SYS containing a
%   transition matrix transMat, a deterministic update law dMat, and a
%   list of cumulative/incidence/deterministic/removed states
%   CStates/IStates/DStates/Astates. The output is intended to be used
%   as input to getFILT.
%
%   SYS.transMat(i,j) defines the rate of the transition from the
%   compartment i to compartment j.
%
%   SYS.dMat defines the deterministic linear dynamics, used to
%   describe the evolution of the infectious pressure. It is a matrix,
%   whose rows correspond to the contributions from the states defined
%   by the rows of transMat, to these dynamics, i.e., for a scalar
%   deterministic state phi_k and a state vector x_k, the update law
%   is phi_{k+1} = dMat*x_k.
%
%   CStates, IStates, DStates, and AStates are arrays of indices which
%   define properties of the corresponding states (given by transMat)
%   in the following way:
%
%   -SYS.CStates: states that will get cumulative counterparts in
%   order to, e.g., allow for comparison with measured data.
%
%   -SYS.IStates: states that similarly will get incidence
%   counterparts.
%
%   -SYS.DStates: deterministic states. The corresponding columns of
%   transMat are all zero, since transitions into deterministic states
%   is not supported.
%
%   -SYS.AStates: states that will be removed in the final model. The
%   purpose of including states in transMat that will be removed later
%   is to represent the transitions from other states into these sink
%   states in a convenient way.
%
%   See also getFILT.