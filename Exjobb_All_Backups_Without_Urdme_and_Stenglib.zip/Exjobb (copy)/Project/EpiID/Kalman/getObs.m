function Obs = getObs(obsrates)
%GETOBS Observation model for compartment model.
%   OBS = GETOBS(OBSRATES) produces an observation model OBS from the
%   struct OBSRATES (compare getFILT).
%
%   The struct OBSRATES has the following fields:
%
%   -states: Cell vector where each element define the indices of
%   states which contribute to a measurement in the model through a
%   linear combination.
%
%   -weights: Cell vector where each element define the weights of the
%   states defined in indobs to determine the measurement, i.e, an
%   element [1 2] in indobs and the corresponding element [a b] in
%   indobspars indicates a measurement of the form a*state#1 +
%   b*state#2.
%
%   -Nstates: Number of states in total in the model.
%
%   -R0: Vector of additive measurement noise.
%
%   -rdiag: Vector of multiplicative measurement noise.
%   
%   On return, OBS contains three fields:
%
%   -OBS.H a sparse matrix with OBSRATES.Nstates columns where every
%   row represents one measurement.
%
%   -OBS.R0 a sparse diagonal matrix with diagonal elements defined by
%   OBSRATES.R0.
%
%   -OBS.rdiag is simply given directly by OBSRATES.rdiag.
%
%   See also getFILT.

% S. Engblom 2022-05-09 (Based on code getC19obs)

% H. Runvik 2020-10-14

% immediate assembly
Nobs = numel(obsrates.states);
ii = repelem(1:Nobs,cellfun('prodofsize',obsrates.states));
jj = cat(2,obsrates.states{:});
ss = cat(2,obsrates.weights{:});

% struct
Obs.H = sparse(ii,jj,ss,Nobs,obsrates.Nstates);

% covariance model for diagonal
Obs.R0 = spdiags(obsrates.R0,0,Nobs,Nobs);
Obs.rdiag = obsrates.rdiag(:);
