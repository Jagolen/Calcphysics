function [xx,PP] = initFilt(yy,KF,DF)
%INITFILT Initial state estimation for Kalman compartment filter.
%   [xx,PP] = INITFILT(yy,KF,DF) estimates an initial state xx and a
%   corresponding covariance matrix PP for initial data yy, filter KF,
%   and observation model DF, see getFILT and getOBS, respectively.
%
%   The first step of the algorithm removes all cumulative states from
%   F, H, and yy to produce (F_red,H_red,yy_red). The dominating
%   eigenvector of F_red is then projected onto the subspace defined
%   by H_red*xx_red = yy_red, under a positivity constraint. For
%   cumulative states that are measured, the initial state is taken
%   directly as the measurement, and the remaining cumulative states
%   are set to zero. The covariance matrix PP is assumed to be
%   diagonal with entries proportional to the states squared.
%
%   By initializing the filter like this, transients are reduced. In
%   particular, if the system would be initialized from the
%   eigenvector and simulated without perturbations, the relative
%   magnitude of the non-cumulative states would remain constant.
%
%   Assumptions:
%
%   -All modes of the system dynamics other than the dominating one is
%   neglected (which would be the case if the system has been running
%   without perturbations for a sufficently long period).
%
%   -The measurements are accurate, i.e., the elements of xx will
%   satisfy H*xx = yy.
%
%   Known issue:
%
%   -If the dominating eigenvalue is less than one, some
%   parametrizations of the F matrix results in the dominating
%   eigenvector being confined to a certain subspace (when one state
%   is "slow to empty"). This will give unreasonable zero
%   initialization of some states

% S. Engblom 2022-05-09 (based on code initC19filt)

% H. Runvik 2021-03-04 (Covariance init)
% H. Runvik 2021-02-22 (NaN handling)
% H. Runvik 2020-10-25 (Revision)
% H. Runvik 2020-10-13 (Revision)
% H. Runvik 2020-10-02 (Revision)
% H. Runvik 2020-09-14

% remove cumulative states from F
F_red = KF.F(~KF.CStates,~KF.CStates);
  
% remove measurements of cumulative states (assuming directly
% measured, i.e., not combined with other states)
H_red = DF.H(:,~KF.CStates);
H_idx = all(H_red == 0,2);
DStates = mod(find(DF.H(H_idx,:)')-1,size(DF.H,2))+1;
% [~,Dstates] = find(DF.H(H_idx,:)); % *** ?
% (DStates = cumulative states measured directly or without other
% cumulative states?)

% remove NaN (missing) measurements
NaN_idx = isnan(yy);
yy_red = yy(~H_idx & ~NaN_idx);
H_red = H_red(~H_idx & ~NaN_idx,:);
  
% find dominating eigenvalue of F
[V,aDiag] = eig(F_red,'vector');
[~,imax] = max(real(aDiag)); % ignore imaginary part for now
Vmax = V(:,imax);
  
% rescale the dominating eigenvector to fit measured data
Vscaled = Vmax*((H_red*Vmax)\yy_red);

% Estimated state satisfying H*xx = yy, this determines xx up to a
% vector in the nullspace of H. The remaining vector is determined so
% that the projections of Vscaled and xx onto the nullspace coincide.
  
% unconstrained version:
H_null = null(full(H_red))';
S = [H_red; H_null];
xx_red = S\[yy_red; H_null*Vscaled];
  
% with positivity constraint:
%opts = optimoptions(@lsqlin,'Display','off');
%xx_red = lsqlin(eye(size(F_red)),Vscaled,[],[],H_red,yy_red,zeros(size(F_red,2),1),[],[],opts);
  
% add remaining elements of xx
xx = zeros(numel(KF.CStates),1);
xx(~KF.CStates) = xx_red;
xx(DStates) = yy(H_idx);
  
% safety check: violation of non-complex assumption
ix = imag(xx);
rx = real(xx);
if any(abs(ix) > 0.01*abs(rx))
  % (note: in case this happens we need to think again)
  warning('Large imaginary part detected.');
end
xx = rx;
  
% covariance init
observed_idx = sum(DF.H(~NaN_idx,:),1) >= 1; % *** any(.,1)?
pp = zeros(1,size(DF.H,2));
pp(observed_idx) = 1;
pp(~observed_idx) = 4;
PP = diag(xx).^2.*pp;
% *** use of the observation model R0+rdiag.*yy.^2
