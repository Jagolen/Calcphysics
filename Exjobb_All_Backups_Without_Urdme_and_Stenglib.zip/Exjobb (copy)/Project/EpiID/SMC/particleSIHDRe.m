%particleSIHDRe.m Particle filter for the SIHDRe-model.

% First try: Sequential importance sampling with resampling (SIR)
% bootstrap particle filter in combination with states estimates
% from Kalman filter. 

% S. Engblom 2022-12-08 (minor fix due to new kalman.m)
% J. Evaeus 2022-06-14

rng('default') % for reproducibility

% data
load data/umod_SIHDRe

% static rates
rates.gammaI = 1/7;
rates.gammaH = 1/10;
rates.FIH = 0.02;
rates.FHD = 0.10;
tau = 1;
rates.rho = -log(0.5)/tau;
% *** known correct rates for now

Nstates = 5;

% SMC window
Nfit = 4; % fit Nfit days at a time...
Ndata = 10; % ...to Ndata points per fit

% data available for identification
tspan = umod.tspan;
Ntime = numel(tspan);
% States in umod.U: [phi,S,I,H,Dead,R].
Data = umod.U(4:5, :); % We measure H, D

J = 50; % number of particles
Jt = J/3; % threshold for resampling
weights = 1/J*ones(J,1); % set particle weights
beta_estimates = zeros(Ntime,1);
FID_estimates = zeros(Ntime,1);
beta_sigmas = zeros(Ntime,1);
FID_sigmas = zeros(Ntime,1);

% for illustration:
beta_particles = zeros(Ntime, J);
FID_particles = zeros(Ntime, J);
weights_particles = zeros(Ntime,J);

% Initialize particles from prior. 
general_prior = 0;
R0_Hyp = [2 2]; % shape parameters for prior
R0_PQ = [0.5 2]; % range of prior
FID_Hyp= [3,2]; % shape 
FID_PQ = [0 5e-3]; % range
if general_prior
  R0 = betarnd(R0_Hyp(1), R0_Hyp(2), [J,1]);
  R0 = rescale(R0, R0_PQ(1), R0_PQ(2)); 
  beta = R0.^2*rates.gammaI;
  FID = betarnd(FID_Hyp(1), FID_Hyp(2), [J,1]);
  FID = rescale(FID, FID_PQ(1), FID_PQ(2));
else
  % Initialize close to true values
  beta = normrnd(0.1451, 0.05, [J,1]); 
  FID = normrnd(0.003, 0.001, [J,1]);
  % Avoid negative values 
  FID = max(0,FID);
  beta = max(0,beta); 
end

beta_mean = mean(beta);
FID_mean = mean(FID);

beta_estimates(1) = beta_mean;
FID_estimates(1) = FID_mean;

% build (a single) datafilter 
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]}; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 

% States
xx = zeros(Nstates, Ntime, J);
PP = zeros(Nstates, Nstates, Ntime, J); 

% Initial states:
for j = 1:J
  % For now, just initialize from true states:
  xx(:,1,j) = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
  PP(:,:,1,j) = diag(xx(:,1,j)+1);
end

% overall initial state from mixing particles according to weights
xxa = zeros(Nstates,Ntime);
PPa = zeros(Nstates,Nstates,Ntime);
[xxa(:,1),PPa(:,:,1)] = gmix(weights,xx(:,1,:),PP(:,:,1,:));

% Choose some spread for sampling particles
sigma_R0 = ((R0_PQ(2)-R0_PQ(1))/5);  
sigma_FID = ((FID_PQ(2)-FID_PQ(1))/5);

% Loop over data temporally
for k = 2:Nfit:Ntime
  display(k)
  % chunk to fit
  ixfit = k:min(k+Nfit-1, Ntime);
  Nfit_ = numel(ixfit);
  ixdata = k:min(k+Ndata-1,Ntime);
    
  % Assumption on parameter dynamics:
  % R_(k+1) = R_(k) + mu*(1-R_k) + q_r
  % FID_(k+1) = FID_(k) + q_f,
  % where q_r and q_f are zero-mean Gaussian noise. 
  mu = 0.1;% For now
  
  % For now, assumptions on dynamics are for R0, so sample R0 and
  % then transform to get beta
  R0_mean = sqrt(beta_mean/rates.gammaI);
  R0 = normrnd(R0_mean + mu*(1-R0_mean), sigma_R0, [J,1]);
  % avoid negative values 
  R0 = max(0,R0);
  beta = R0.^2*rates.gammaI;
  FID = normrnd(FID_mean, sigma_FID, [J,1]);
  FID = max(0,FID);
  
  % Build Kalman filters
  KF = cell(1,J);
  for j = 1:J
    rates.beta = beta(j);
    rates.FID = FID(j);
    Sys = getSyst('SIHDRe', rates);
    Sys.Q0 = ones(Nstates,1);
    Sys.qdiag = [0.05^2];
    KF{j} = getFilt(Sys);
    
    [xx_,PP_, ww_] = kalman(xx(:,k-1,j), PP(:,:,k-1,j), ...
                            KF{j}, Data(:,ixdata), ...
                            DF);
    ww_ = ww_.logL;
    
    for i = 1:numel(ixfit)      
      xx(:,ixfit(i),j) = xx_(:,2); % xx_(:,1) a priori estimates, xx_(:,2) a posteriori
      PP(:,:,ixfit(i),j) = PP_(:,:,2);
    end
 
    ww_ = sum(ww_);
    xx(:,ixfit,j) = xx_(:,1:Nfit_,2);
    PP(:,:,ixfit,j) = PP_(:,:,1:Nfit_,2);
    weights(j) = exp(ww_)*weights(j);% In case of bootstrap filter,
                                     % only update with likelihood
  end
  
  weights = weights/sum(weights); % normalize
  Jess = 1/sum(weights.^2); % effective sample size
  
  beta_particles(k,:) = beta;
  FID_particles(k,:) = FID;
  weights_particles(k,:) = weights;
  
  if Jess < Jt % resample
    % next: adopt some reseampling scheme for efficiency
    counts = mnrnd(J,weights);
    locs = find(counts);
    % store values to be resampled
    beta_ = beta;
    FID_ = FID;
    
    beta = [];
    FID = [];
    
    for i = 1:numel(locs)
      loc = locs(i);
      beta = [beta; beta_(loc)*ones(counts(loc),1)];
      FID = [FID; FID_(loc)*ones(counts(loc),1)];
    end
    weights = 1/J*ones(J,1); % reset weights:
  end
  
  % store:
  beta_mean = sum(weights.*beta);
  R0 = sqrt(beta/rates.gammaI);
  R0_mean = sqrt(beta_mean/rates.gammaI);
  FID_mean = sum(weights.*FID);
  
  % overall state estimate:
  [xxa(:,ixfit),PPa(:,:,ixfit)] = ...
      gmix(weights,xx(:,ixfit,:),PP(:,:,ixfit,:));
  
  for i = 1:numel(ixfit)
    beta_estimates(ixfit(i)) = beta_mean;
    FID_estimates(ixfit(i)) = FID_mean;
    % weighted covariances:
    beta_sigmas(ixfit(i)) = sqrt(1/(1-sum(weights.^2))*sum(weights.*(beta- ...
                                                      beta_mean).^2));
    
    FID_sigmas(ixfit(i)) = sqrt(1/(1-sum(weights.^2))*sum(weights.*(FID- ...
                                                      FID_mean).^2));
  end
end

% states estimates
figure(3), clf,
subplot(4,1,1);
U = umod.U(:,1:Ntime);
h = plot(tspan,U(1,:),'b--', ...
         tspan,xxa(1,:),'r');
std_ = permute(sqrt(PPa(1,1,:)),[1 3 2]);
errorshade(tspan,xxa(1,:)-std_,xxa(1,:)+std_,get(h(2),'Color'));
title('phi');
legend('URDME','SMC');
subplot(4,1,2);
h = plot(tspan,U(3,:),'b--', ...
         tspan,xxa(2,:),'r');
std_ = permute(sqrt(PPa(2,2,:)),[1 3 2]);
errorshade(tspan,xxa(2,:)-std_,xxa(2,:)+std_,get(h(2),'Color'));
title('I');
subplot(4,1,3);
h = plot(tspan,U(4,:),'b--', ...
         tspan,xxa(3,:),'r');
std_ = permute(sqrt(PPa(3,3,:)),[1 3 2]);
errorshade(tspan,xxa(3,:)-std_,xxa(3,:)+std_,get(h(2),'Color'));
title('H');
subplot(4,1,4);
h = plot(tspan,U(5,:),'b--', ...
         tspan,xxa(4,:),'r');
std_ = permute(sqrt(PPa(4,4,:)),[1 3 2]);
errorshade(tspan,xxa(4,:)-std_,xxa(4,:)+std_,get(h(2),'Color'));
title('D');

% parameter estimates
figure(4), clf,
subplot(2,1,1)
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3, ...
                                                  1));
h = plot(tspan, ubeta, tspan, beta_estimates);
errorshade(tspan, (beta_estimates - beta_sigmas)', (beta_estimates + ...
           beta_sigmas)', get(h(2), 'Color'));
title('beta')
subplot(2,1,2)
uFID = umod.private.FID(1:Ntime);
h = plot(tspan, uFID, tspan, FID_estimates);
errorshade(tspan, (FID_estimates-FID_sigmas)', (FID_estimates ...
           + FID_sigmas)', get(h(2), 'Color'));
title('FID')

% Display particles
figure(5), clf,
plot_weights = weights_particles;
nulls = find(plot_weights ==0);
% avoid error for plotting points of size zero
plot_weights(nulls) = 1e-8;
plot_weights = 1000*plot_weights;
subplot(2,1,1)
hold on
real_beta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3,1));
%plot(tspan,real_beta)%umod.private.beta)
plot(tspan, sqrt(real_beta/rates.gammaI));
scatter(tspan, sqrt(beta_particles/rates.gammaI), plot_weights)
title('R0')
subplot(2,1,2)
hold on
plot(tspan, umod.private.FID)
scatter(tspan, FID_particles, plot_weights)
title('FID')

if ~exist('savetofile', 'var')
  savetofile = false;
end

if savetofile
  postrates = struct();
  postrates.FID = FID_estimates;
  postrates.beta = beta_estimates;
  save('SMC/results/postrates.mat', 'postrates')
end