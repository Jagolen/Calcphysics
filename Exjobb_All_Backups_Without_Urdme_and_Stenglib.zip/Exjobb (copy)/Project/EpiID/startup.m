%STARTUP Startup for EpiID.

% S. Engblom 2022-05-17

% link = location of this startup.m
link = mfilename('fullpath');
link = link(1:end-numel(mfilename));

% path to folders
addpath(genpath([link 'auxil/']));
addpath(genpath([link 'data/']));
addpath(genpath([link 'DynOpt/']));
addpath(genpath([link 'EM/']));
addpath(genpath([link 'IMM/']));
addpath(genpath([link 'Kalman/']));
addpath(genpath([link 'SMC/']));
addpath(genpath([link 'test/']));
addpath(genpath([link 'URDME/']));
