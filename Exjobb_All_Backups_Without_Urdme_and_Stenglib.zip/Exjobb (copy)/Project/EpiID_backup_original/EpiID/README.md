# epidemic-toy

## About 

This README describes the folder structure in the EpiID repository. 

## Authors

* Stefan Engblom (stefane 'at' it.uu.se)
* Jonas Evaeus (jonas.evaeus 'at' it.uu.se)

# Installation

1. Clone the repository. 
2. Make sure that the dependencies are installed and initialized. 
3. Initialize by starting Matlab and running 'startup' in the main
   directory.

## /DynOpt/

Dynamic optimization. 

## /EM/

Expectation-maximization algorithm. 

## /IMM/ 

Interacting multiple model filter algorithm. 

## /Kalman/

Kalman filtering. 

## /SMC/

Sequential Monte Carlo algorithms. 

## /URDME/

Generate synthetic data using URDME. 

## /notes/

Notes on project development. 

# /test/ 

Testing facilities for the project. 

## /auxil/

Auxiliary functions.

## /data/

Generated synthetic data, both over epidemiological states
and the "true" parameter values of time-varying parameters. 
