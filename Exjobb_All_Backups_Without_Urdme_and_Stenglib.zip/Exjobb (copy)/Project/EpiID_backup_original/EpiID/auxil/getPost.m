function rates = getPost(model, method)
%Posterior rates of the chosen specified model and method. 

%   rates = getPost(model, method) returns the posterior rates
%   of the specified epidemiological model, which were inferred
%   using the specified method. 

%   Currently simply returns the known fixed rates used in SIHDRe
%   model along with posterior estimates of dynamic rate FID. 

% J. Evaeus 2022-01-09

if nargin < 1
  model = 'SIHDRe';
  method = 'SMC';
end

if model == 'SIHDRe'
  % static rates
  rates.gammaI = 1/7;
  rates.gammaH = 1/10;
  rates.FIH = 0.02;
  rates.FHD = 0.10;
  tau = 1;
  rates.rho = -log(0.5)/tau;
  % *** known correct rates for now
  
  % dynamic rates, return some reasonable candidate for mean(prior)
  ntime = 141;
  load([method '/results/postrates.mat'])
  rates.FID = postrates.FID;
  rates.beta = postrates.beta;
end

