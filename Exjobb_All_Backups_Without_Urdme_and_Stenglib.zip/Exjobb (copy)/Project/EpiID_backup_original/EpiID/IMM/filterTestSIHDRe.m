%filterTestSIHDRe Filter test for the SIHDRe-model.

% S. Engblom 2022-05-18 (Refactored)
% S. Engblom 2022-05-07

% data
load data/umod_SIHDRe

% static rates
rates.gammaI = 1/7;
rates.gammaH = 1/10;
rates.FIH = 0.02;
rates.FHD = 0.10;
tau = 1;
rates.rho = -log(0.5)/tau;
% *** known correct rates for now

% the dynamic (unknown) rates are placed on a mesh, here taken to be
% (scaled) Cartesian:
R0 = linspace(0.5,2.0,16);
beta = R0.^2*rates.gammaI;
IFR = linspace(0.2e-2,0.5e-2,8);
FID = IFR-rates.FIH*rates.FHD;
FID(1) = 0.5*(FID(1)+FID(2)); % (avoid 0)

% the above are the midpoints of the centroids, here follows the
% edges:
edges = @(x)[x(1)-0.5*(x(2)-x(1)) 0.5*(x(1:end-1)+x(2:end)) ...
             x(end)+0.5*(x(end)-x(end-1))];
beta_edg = edges(beta);
FID_edg = edges(FID);

% midpoint mesh with (diagonal) mass matrix
[beta_,FID_] = meshgrid(beta,FID);
Mass = diff(FID_edg)'*diff(beta_edg);
Mass = Mass(:)/sum(Mass(:));
Nparams = numel(Mass);

% dynamics of weights via a simple diffusion
Dbeta = ndop([-1 1]',1,numel(beta),{1})+ ...
        ndop([1 -1]',2,numel(beta),{numel(beta)})+ ...
        ndop([1 -2 1]',2,numel(beta));
DFID = ndop([-1 1]',1,numel(FID),{1})+ ...
       ndop([1 -1]',2,numel(FID),{numel(FID)})+ ...
       ndop([1 -2 1]',2,numel(FID));
% diffusion speed:
betasigma = 2.0;
FIDsigma = 0.1;
D = betasigma*kron(Dbeta,speye(size(DFID)))+ ...
    FIDsigma*kron(speye(size(Dbeta)),DFID);
% trapezoidal rule:
D = (speye(size(D))-0.5*D)\(speye(size(D))+0.5*D);
% *** the above should rather be the Fokker-Planck equation of a
% suitable process and should take in that the mesh is non-uniform

% inspect the above dynamics
% $$$ r = reshape(repmat(rand(1,numel(beta)),[numel(FID) 1]),[],1);
% $$$ figure(1), clf, hold on, view(3)
% $$$ for i = 1:5, r = D*r; surf(beta_,FID_,i+reshape(r,size(beta_))); end
% $$$ 
% $$$ r = reshape(repmat(2*rand(numel(FID),1),[1 numel(beta)]),[],1);
% $$$ figure(2), clf, hold on, view(3)
% $$$ for i = 1:5, r = D*r; surf(beta_,FID_,i+reshape(r,size(beta_))); end

% build filters
KF = cell(1,Nparams);
Nstates = 5; % Kalman: [phi I H D R]
for j = 1:Nparams
  rates.beta = beta_(j);
  rates.FID = FID_(j);
  Sys = getSyst('SIHDRe',rates);
  Sys.Q0 = ones(Nstates,1);
  Sys.qdiag = [0.05^2];
  KF{j} = getFilt(Sys);
end

% data available for identification
tspan = umod.tspan;
Ntime = numel(tspan);
Data = umod.U(4:5,1:Ntime);

% build (a single) datafilter
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates);

% IMM-window
Nfit = 4;   % fit Nfit days at a time...
Ndata = 10; % ...to Ndata points per fit

% repeated trials
Mtrials = 10;
for ktrial = 1:Mtrials
  
% state for all filters
xx = zeros(Nstates,Ntime,Nparams);
PP = zeros(Nstates,Nstates,Ntime,Nparams);

% initial weights for the filters
ww = Mass; % uniform start
ww = [0 0 0 0 0 0 1 1]'*[zeros(1,4) 1 1 1 zeros(1,9)];
ww = ww+1e-6;
ww = ww(:)/sum(ww(:));
% ***

% individual initial states
for j = 1:Nparams
  %[xx(:,j),PP(:,:,j)] = initFilt(Data(1),KF{j},DF);
  % *** for now:
  xx(:,1,j) = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
  PP(:,:,1,j) = diag(xx(:,j)+1);
end
% overall initial state from mixing
xxa = zeros(Nstates,Ntime);
PPa = zeros(Nstates,Nstates,Ntime);
wwa = zeros(Nparams,Ntime);
[xxa(:,1),PPa(:,:,1)] = gmix(ww,xx(:,1,:),PP(:,:,1,:));
wwa(:,1) = ww;

% the IMM
i = 2;
while 1
  % sample a random chunk to keep constant
  Nfit_ = geornd(1/(Nfit-1))+2; % mean(Nfit_) = Nfit, min(Nfit_) = 2
  Ndata_ = Nfit_+(Ndata-Nfit); % suitable separation Ndata-Nfit = 6

  % chunk to fit
  ixfit = i:min(i+Nfit_-1,Ntime);
  Nfit_ = numel(ixfit);
  ixdata = i:min(i+Ndata_-1,Ntime);
  Ndata_ = numel(ixdata);

  % mixing parameters
  MU = full(D'.*ww);
  ww = sum(MU,1)';
  MU = MU./ww';

  % individual filters
  for j = 1:Nparams

    % mixed estimates
    [xx_,PP_] = gmix(MU(:,j),xx(:,i-1,:),PP(:,:,i-1,:));

    % Kalman filter
    [xx_,PP_,ww_] = kalman(xx_,PP_,KF{j},Data(:,ixdata),DF);
    ww_ = ww_.logL;
    if any(isinf(ww_))
      % one index j of the parameters produced a bad likelihood: resample a
      % new value of Nfit_ and try again
      disp('Lost a filter!');
      j = -1; % (signal this)
      break;
    end
    ww_ = sum(ww_); % *** weights
    xx(:,ixfit,j) = xx_(:,1:Nfit_,2);
    PP(:,:,ixfit,j) = PP_(:,:,1:Nfit_,2);
    ww(j) = ww(j)*exp(ww_); % *** log-sum-exp!
  end
  if j == -1 % (catch signal)
    continue;
  end

  % normalization
  ww = ww./sum(ww);
  wwa(:,ixfit) = repmat(ww,[1 Nfit_]);

  % overall estimate
  [xxa(:,ixfit),PPa(:,:,ixfit)] = ...
      gmix(ww,xx(:,ixfit,:),PP(:,:,ixfit,:));
  
  % break condition
  i = ixfit(end)+1;
  if i > Ntime, break; end
end

% combining trials logic
if ktrial == 1
  xxa_ = xxa;
  PPa_ = PPa;
  wwa_ = wwa;
else
  xxa_ = xxa_*(ktrial-1)/ktrial+xxa*(1/ktrial);
  PPa_ = PPa_*(ktrial-1)/ktrial+PPa*(1/ktrial);
  wwa_ = wwa_*(ktrial-1)/ktrial+wwa*(1/ktrial);
end
if ktrial == Mtrials
  xxa = xxa_;
  PPa = PPa_;
  wwa = wwa_;
end
ktrial

end % repeated trials

% *** plot with errorbars!

% state estimates
figure(1), clf,
subplot(4,1,1);
U = umod.U(:,1:Ntime);
h = plot(tspan,U(1,:),'b--', ...
         tspan,xxa(1,:),'r');
std_ = permute(sqrt(PPa(1,1,:)),[1 3 2]);
errorshade(tspan,xxa(1,:)-std_,xxa(1,:)+std_,get(h(2),'Color'));
title('phi');
legend('URDME Data','IMM Est');
subplot(4,1,2);
h = plot(tspan,U(3,:),'b--', ...
         tspan,xxa(2,:),'r');
std_ = permute(sqrt(PPa(2,2,:)),[1 3 2]);
errorshade(tspan,xxa(2,:)-std_,xxa(2,:)+std_,get(h(2),'Color'));
title('I');
subplot(4,1,3);
h = plot(tspan,U(4,:),'b--', ...
         tspan,xxa(3,:),'r');
std_ = permute(sqrt(PPa(3,3,:)),[1 3 2]);
errorshade(tspan,xxa(3,:)-std_,xxa(3,:)+std_,get(h(2),'Color'));
title('H');
subplot(4,1,4);
h = plot(tspan(2:end),diff(U(5,:)),'b--', ...
         tspan(2:end),diff(xxa(4,:)),'r');
std_ = permute(sqrt(PPa(4,4,:)),[1 3 2]);
errorshade(tspan(2:end),diff(xxa(4,:)-std_),diff(xxa(4,:)+std_),get(h(2),'Color'));
title('D_{inc}');

% parameter estimates
figure(2), %clf,
subplot(2,1,1);
% correction for beta(t) vs beta_E(t) as in beta(t)*S*I/Sigma =
% beta_E(t)*I
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3,1));
betaest = beta_(:)'*wwa;
betastd = sqrt(beta_(:)'.^2*wwa-betaest.^2);
h = plot(tspan,ubeta,'k',tspan,betaest);%,tspan,beta_(:)'*(D^10*wwa),'--');
errorshade(tspan,betaest-betastd,betaest+betastd,get(h(2),'Color'));
title('beta');
subplot(2,1,2);
uFID = umod.private.FID(1:Ntime);
h = plot(tspan,uFID,'k',tspan,FID_(:)'*wwa);%,tspan,FID_(:)'*(D^10*wwa),'--');
FIDest = FID_(:)'*wwa;
FIDstd = sqrt(FID_(:)'.^2*wwa-FIDest.^2);
errorshade(tspan,FIDest-FIDstd,FIDest+FIDstd,get(h(2),'Color'));

title('FID');

return;

% response curve
xx = [NaN; 1; 0; 0; 0];
xx(1) = xx(2);
PP = eye(5);

KF = reshape(KF,size(beta_));
r = zeros(2,30);

KF_ = KF{4,8};
xx_ = xx;

for i = 1:size(r,2)
  xx_ = KF_.F*xx_;
  r(:,i) = DF.H*xx_;
end
