function ok = spin(ix)
%SPIN Tests for EpiID.

% S. Engblom 2022-12-09

ftests = {@l_spin1 @l_spin2};
stests = {'Spin #1 (getFilt)' ...
          'Spin #2 (initFilt)'};

if nargin == 0
  ix = 1:size(ftests,2);
end
ok = runtest('SPIN (EpiID)',ftests(ix),stests(ix));

%-----------------------------------------------------------------------
function ok = l_spin1
%L_SPIN1 Test of getFilt.

ok = 1;
tol = 1e-10;

% basic checks
D.pJac = ...
    [0.5 0   0   0  ; ....
     0.1 0   0   0  ; ...
     0   0.7 0   0  ; ...
     0   0   0.4 0  ; ...
     0   0   0   0.2; ...
     0   0   1   0; ...
     0   0   0   1];
D.N = [-1 -1  0  0  1   0   0; ...
        1  0 -1  0  0   0   0; ...
        0  1  1 -1  0   0   0; ...
        0  0  0  0  0   1  -1];
D.CStates = 1; % compartments which get added cumulative state
D.IStates = 2; % compartment which gets added incidence state
D.DStates = 4; % deterministic compartments
D.AStates = [];
D.Q0 = ones(6,1);
D.qdiag = 0.5^2;
KFD = getFilt(D);

% ver = 2
C.transMat = ...
    [0 0.5 0.1   0   0; ...
     0   0 0.7   0   0; ...
     0   0   0   0 0.4; ...
     0.2 0   0   0   0;...
     0   0   0   0   0];
C.AStates = 5; % states that should be removed
C.dMat = [0 0 1 0 0];
C.CStates = 1; % compartments which get added cumulative state
C.DStates = 4; % deterministic compartments
C.IStates = 2; % compartment which gets added incidence state
C.Q0 = ones(5,1);
C.qdiag = 0.5^2;
KFC = getFilt(C,2);

% they the same?
% $$$ isequal(KFC.CStates,KFD.CStates)
% $$$ norm(KFC.F-KFD.F,inf) < tol
% $$$ norm(KFC.Qp(:)-KFD.Qp(:),inf) < tol
% $$$ norm(KFC.Qv-KFD.Qv,inf) < tol

FC = [0.4 0 0 0.2 0 0; 0.5 0.3 0 0 0 0; 0.1 0.7 0.6 0 0 0; 0 0 1 0 0 0;...
    0 0 0 0.2 1 0; 0.5 0 0 0 0 0];
QvC = [0.26 0 0 0.04 0 0; 0.25 0.49 0 0 0 0; 0.01 0.49 0.16 0 0 0; ...
       0 0 1 0 0 0; 0 0 0 0.04 0 0; 0.25 0 0 0 0 0];
QpC = zeros(6,6,6);
QpC(:,:,1) = [0.6 -0.5 -0.1 0 0 -0.5; -0.5 0.5 0 0 0 0.5;....
              -0.1 0 0.1 0 0 0; zeros(2,6); -0.5 0.5 0 0 0 0.5];
QpC(2:3,2:3,2) = [0.7 -0.7; -0.7 0.7];
QpC(3,3,3) = 0.4;
QpC(1,1,4) = 0.2; QpC(5,1,4) = 0.2;
QpC(1,5,4) = 0.2; QpC(5,5,4) = 0.2;
CStatesC = [false(4,1); true; false];

ok = ok && norm(KFD.F-FC,inf) < tol && ...
     norm(KFD.Qp(:)-QpC(:),inf) < tol && ...
     norm(KFD.Qv-QvC,inf) < tol && ...
     isequal(KFD.CStates,CStatesC);

ok = ok && norm(KFC.F-FC,inf) < tol && ...
     norm(KFC.Qp(:)-QpC(:),inf) < tol && ...
     norm(KFC.Qv-QvC,inf) < tol && ...
     isequal(KFC.CStates,CStatesC);

% "minimal full" example
D.pJac = ...
    [2 0 0; ...
     0 0 3; ...
     0 0 4; ...
     5 0 5];
D.N = ...
    [-1   1   0   0; ...
      1   0   1   0; ...
      0   0   0   1];
D.CStates = [2 1];  % compartments which get added cumulative state
D.DStates = 3;      % deterministic compartments
D.AStates = 2;      % states that should be removed
D.IStates = [1 2];  % compartment which gets added incidence state
D.Q0 = ones(7,1);
D.qdiag = 0.5^2;
KFD = getFilt(D);

% ver = 2
C.transMat = ...
    [0 2 0; ...
     0 0 0; ...
     3 4 0];
C.dMat = [5 0 6];
C.CStates = [2 1];  % compartments which get added cumulative state
C.DStates = 3;      % deterministic compartments
C.AStates = 2;      % states that should be removed
C.IStates = [1 2];  % compartment which gets added incidence state
KFC = getFilt(C,2);

% they the same?
% $$$ isequal(KFC.CStates,KFD.CStates)
% $$$ norm(KFC.F-KFD.F,inf) < tol
% $$$ norm(KFC.Qp(:)-KFD.Qp(:),inf) < tol
% $$$ norm(KFC.Qv-KFD.Qv,inf) < tol

CStates = false(6,1); CStates(3:4) = true;
F = [ ...
    -1     3     0     0     0     0; ... % "1"
     5     6     0     0     0     0; ... % "3" (det)
     2     4     1     0     0     0; ... % "2"_cum
     0     3     0     1     0     0; ... % "1"_cum
     0     3     0     0     0     0; ... % "1"_inc
     2     4     0     0     0     0];    % "2"_inc
Qv = [ ...
     4     9     0     0     0     0; ...
    25     0     0     0     0     0; ...
     4    16     0     0     0     0; ...
     0     9     0     0     0     0; ...
     0     9     0     0     0     0; ...
     4    16     0     0     0     0];
Qp = zeros(6,6,6);
Qp(:,:,1) = [ ... % * "1"-state
    2     0    -2     0     0    -2; ...
    0     0     0     0     0     0; ...
   -2     0     2     0     0     2; ...
    0     0     0     0     0     0; ...
    0     0     0     0     0     0; ...
   -2     0     2     0     0     2];
Qp(:,:,2) = [ ... % * "3"-state (det)
    3     0     0     3     3     0; ...
    0     0     0     0     0     0; ...
    0     0     4     0     0     4; ...
    3     0     0     3     3     0; ...
    3     0     0     3     3     0; ...
    0     0     4     0     0     4];

ok = ok && isequal(KFC.CStates,CStates) && ...
     isequal(KFC.F,F) && isequal(KFC.Qv,Qv) && ...
     isequal(KFC.Qp,Qp);

ok = ok && isequal(KFD.CStates,CStates) && ...
     isequal(KFD.F,F) && isequal(KFD.Qv,Qv) && ...
     isequal(KFD.Qp,Qp);

% SIHDRe: new version vs ver = 2
rates.beta = 0.13;
rates.FID = 0.0031;
rates.gammaI = 0.15;
rates.gammaH = 0.2;
rates.FIH = 0.11;
rates.FHD = 0.17;
FHD = 0.08;
rates.rho = 0.1;
S1 = getSyst('SIHDRe',rates);
K1 = getFilt(S1);
S2 = getSyst('SIHDRe',rates,2);
K2 = getFilt(S2,2);
ok = ok && ...
     norm(K1.F(:)-K2.F(:),inf) < tol && ...
     norm(K1.Qp(:)-K2.Qp(:),inf) < tol&& ...
     norm(K1.Qv(:)-K2.Qv(:),inf) < tol && ...
     norm(K1.Q0(:)-K2.Q0(:),inf) < tol && ...
     norm(K1.qdiag(:)-K2.qdiag(:),inf) < tol;
     
%-----------------------------------------------------------------------
function ok = l_spin2
%L_SPIN2 Test of initFilt.

ok = 1;

%-----------------------------------------------------------------------
function ok = l_spin3
%L_SPIN3 Test mpcloop_beta.

error('Test not updated');
ntime = 20;

beta0 = 0.095;
betavar = beta0*ones(1,ntime);

% setup system
rates = priorenger(inf);
rates.IStates = [7]; % "Dinc"
C19 = getC19syst(rates,1,1);
KF = getC19filt(C19);
nstate = size(KF.F,1);
x0 = ones(nstate,1);

betaIdx = false(nstate,nstate);
betaIdx(3,4) = true;

H = [zeros(1,4) 1 zeros(1,4); zeros(1,5) 1 zeros(1,3); zeros(1,8) 1];

beta.beta = betavar;
beta.betaIdx = betaIdx;

% generate synthetic data
x = LPVsim(KF.F,x0,beta);

y = H*x; % no noise

% setup optimization
F_dynOpt = KF.F([1:6 9],[1:6 9]);
H_dynOpt = H(:,[1:6 9]);
wbeta = 2000;
wy = ones(3,ntime);

beta0_dynOpt = betavar;
x0_dynOpt = x0([1:6 9]);
betaIdx_dynOpt = betaIdx([1:6 9],[1:6 9]);
steplength = 2;
windowlength = 10;

% run optimization
options = optimoptions(@fmincon,'MaxFunctionEvaluations',10000, ...
                       'Display','off');

[x0opt,betaopt,J,K] = mpcloop_beta(y,F_dynOpt,H_dynOpt,betaIdx_dynOpt, ...
                                   wbeta,wy,steplength,windowlength, ...
                                   x0_dynOpt,beta0_dynOpt,options);

ok = size(x0opt,1) == size(F_dynOpt,1) && ...
     size(betaopt,2) == ntime && J > K && K > 0;

%-----------------------------------------------------------------------
