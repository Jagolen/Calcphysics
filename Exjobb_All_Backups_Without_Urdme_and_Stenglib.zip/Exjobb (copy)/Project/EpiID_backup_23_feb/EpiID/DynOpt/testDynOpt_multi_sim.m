%testDynOpt Test of dynamic beta.

% J. Evaeus 2022-01-12 (Adapted to EpiID framework)

% S. Engblom 2022-12-14

if ~exist('windowlength','var')
  windowlength = 80; % What is reasonable here?
end

ntime = 365;
maxfunceval = 2700000;


if ~exist('verb','var')
  verb = false;
end

startday = 1;
endday = 60;

endday_ = startday;

% Tweaked wbeta to make posterior look OK. 
wbeta=2400;%300000;
steplength= 5;%20;

% posterior

postrates = getPost('SIHDRe','SMC');

% load filter data

load data/umod_SIHDRe

tspan = umod.tspan;
Ntime = numel(tspan);
Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)

% define data and filter periods
ixdata = startday:endday+ntime-1;

ixfilter = ixdata;

% specify observation model
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
Nstates = 5; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 

% Initial states. For now, simply initialize on true state:
x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
P0 = diag(x0+1);

[Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,'rts',postrates,Nstates);

S = L.Scov;

F = cell(Ntime,1);
for m = 1:Ntime
  KF_ = KF_func(postrates,Nstates,m);
  F{m} = KF_.F;
end

H = DF.H;
betaIdx = false(obsrates.Nstates-1);
betaIdx(2,1) = true; % element of F where beta is found

beta0 = 0.1*ones(1,ntime);

if verb
  display = 'iter-detailed';
else
  display = 'off';
end
options = optimoptions(@fmincon,'MaxFunctionEvaluations',maxfunceval,...
                       'MaxIterations',6000,'Display',display,...
                       'OptimalityTolerance',2e-5);

[x0_post,betaOpt,J,misfit] = DynOpt(squeeze(Ydata),F,H,betaIdx,wbeta,S,steplength, ...
                                  windowlength,x0,beta0,options);
% True beta
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3, ...
                                                  1));

%%% TESTING
sigma = 1e5;
betaOpt_0 = betaOpt;
%sus = umod.U(2,:); Using susceptible directly
%sus = sigma - umod.U(3,:) - umod.U(4,:) - umod.U(5,:) - umod.U(6,:); % Calculating susceptible from sigma,H,D,I,R
%sus = sigma - Z(2,:,1) - Z(3,:,1) - Z(4,:,1) - Z(5,:,1); % Calculating susceptible from sigma and apriori Kalman of H,D,I,R
%sus = sigma - Z(2,:,2) - Z(3,:,2) - Z(4,:,2) - Z(5,:,2); % Calculating susceptible from sigma and aposteriori Kalman of H,D,I,R
sus = sigma - Z(2,:,3) - Z(3,:,3) - Z(4,:,3) - Z(5,:,3); % Calculating susceptible from sigma and smooth Kalman of H,D,I,R
%WARNING!!! Needs 'rts' in 4th argument when calling Kalman if using
%Z(:,:,3), else use false
betaOpt = betaOpt*sigma./sus;

iters = 5;
all_betaopt = zeros(length(betaOpt), iters); % beta from every iteration
                                             % except the first, which is
                                             % saved as betaOpt_0

all_I = zeros(iters+1, length(betaOpt)); % I from every iteration
all_I(1,:) = umod.U(3,:);

all_H = zeros(iters+1, length(betaOpt)); % H from every iteration
all_H(1,:) = umod.U(4,:);

all_D = zeros(iters+1, length(betaOpt)); % D from every iteration
all_D(1,:) = umod.U(5,:);


% TEST OF SHIFTING BETA
%betaOpt = [betaOpt(2:end) betaOpt(end)];

% First, save the models
genData_multiple(iters, betaOpt)

% Find optimal beta for every model
parfor j = 1:iters
    j
    umod = dload('DynOpt/data/umod_SIHDRe_multiple.mat');
    umod = umod(j)
    tspan = umod.tspan;
    Ntime = numel(tspan);
    Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)
    x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
    P0 = diag(x0+1);
    
    [Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);
    
    S = L.Scov;
    [x0_post,betaOpt,J,misfit] = DynOpt(squeeze(Ydata),F,H,betaIdx,wbeta,S,steplength, ...
                                      windowlength,x0,beta0,options);
    all_betaopt(:,j) = betaOpt;
    all_I(j+1,:) = umod.U(3,:);
    all_H(j+1,:) = umod.U(4,:);
    all_D(j+1,:) = umod.U(5,:);
end

% Find mean and std. div of beta, for every time step
standard_dev = zeros(length(ubeta),1);

for j = 1:length(ubeta)
    standard_dev(j) = sqrt((1/iters)*sum((all_betaopt(j, :) - betaOpt_0(j)).^2));
end
betaOpt_0 = betaOpt_0';

%Plot mean and std. div.
lim1 = betaOpt_0 + 2*standard_dev;
lim2 = betaOpt_0 - 2*standard_dev;
x = 1:141;
betw1 = [x.', lim1];
betw2 = [x.', lim2];
combine = [betw1; flipud(betw2)];
figure(1),hold on
gray = [.7 .7 .7];
% Create shadowed area of mean and 2 std. div of calculated beta
fill(combine(:,1), combine(:,2), gray, 'DisplayName', 'DynOpt')

plot(x, betaOpt_0, 'b', 'DisplayName', 'betaOpt_0')
plot(x, ubeta, 'r', 'DisplayName', 'True beta')
for i = 1:iters
    plot(x,all_betaopt(:,i), 'g', 'HandleVisibility','off')
end

legend
title("steplen: " + steplength + ", Winlen: "+ windowlength + ", Iters: " + iters)
hold off

% Plot I, H and D
figure(2), hold on
plot(x,all_I(1,:),'b','DisplayName','I_0', 'LineWidth',2)
for i = 2:iters+1
    plot(x,all_I(i,:),'r', 'HandleVisibility','off')
end
legend
title("I (Iters: " + iters +")")
hold off

figure(3), hold on
plot(x,all_H(1,:),'b','DisplayName','H_0', 'LineWidth',2)
for i = 2:iters+1
    plot(x,all_H(i,:),'r', 'HandleVisibility','off')
end
legend
title("H (Iters: " + iters +")")
hold off

figure(4), hold on
plot(x,all_D(1,:),'b','DisplayName','D_0', 'LineWidth',2)
for i = 2:iters+1
    plot(x,all_D(i,:),'r', 'HandleVisibility','off')
end
legend
title("D (Iters: " + iters +")")
hold off

%%% End TESTING %%%
return;

function y = KF_func(postrates, Nstates, index)
postrates_ = postrates;
postrates_.beta = postrates.beta(index);
postrates_.FID = postrates.FID(index);
Sys = getSyst('SIHDRe',postrates_);
Sys.Q0 = ones(Nstates,1);
Sys.qdiag = [0.05^2];
y = getFilt(Sys);
end