%% 
%testDynOpt Test of dynamic beta and FID.

% J. Evaeus 2022-01-12 (Adapted to EpiID framework)

% S. Engblom 2022-12-14


%Time the function
tStart = tic;
if ~exist('windowlength','var')
  windowlength = 80; % What is reasonable here?
  %ORIGINAL : 80
end

ntime = 365;
maxfunceval = 2700000^2;


if ~exist('verb','var')
  verb = false;
end

startday = 1;
endday = 60;

endday_ = startday;

% Tweaked wbeta to make posterior look OK. 
wbeta=10000;%300000;
steplength= 20;%20;
%ORIGINAL: 5

% posterior

postrates = getPost('SIHDRe','SMC');

% load filter data

load data/umod_SIHDRe

tspan = umod.tspan;
Ntime = numel(tspan);
Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)

% define data and filter periods
ixdata = startday:endday+ntime-1;

ixfilter = ixdata;

% specify observation model
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
Nstates = 5; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 

% Initial states. For now, simply initialize on true state:
x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
P0 = diag(x0+1);

[Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);

S = L.Scov;

F = cell(Ntime,1);
for m = 1:Ntime
  KF_ = KF_func(postrates,Nstates,m);
  F{m} = KF_.F;
end

H = DF.H;
betaIdx = false(obsrates.Nstates);
betaIdx(2,1) = true; % element of F where beta is found

FIDIdx1 = false(obsrates.Nstates);
FIDIdx1(4, 2) = true;

FIDIdx2 = false(obsrates.Nstates);
FIDIdx2(5, 2) = true;

%theta = [beta; FID]
theta0 = [0.1*ones(1,ntime); 0.003*ones(1,ntime)];

if verb
  display = 'iter-detailed';
else
  display = 'off';
end
options = optimoptions(@fmincon,'MaxFunctionEvaluations',maxfunceval,...
                       'MaxIterations',6000^2,'Display',display,...
                       'OptimalityTolerance',2e-5);

% Initializing w values and result vectors, as well as prior for beta optim
% when doing the gibbs-like method
wbeta = [10000];
wfid = [1000000000];
all_fidopt = zeros(length(wfid), 141);
all_betaopt = zeros(length(wfid), 141);
fid_for_beta = ones(1,141).*mean(postrates.FID);
J_all = zeros(length(wfid));


%Time the loop i.e. the Dynopt calls
tloopstart = tic;
parfor i = 1:length(wfid)
    wfid(i)

    %Change DynOpt_beta_and_FID_alt to DynOpt_beta_and_FID and remove wfid
    %field to use the other function
    [x0_post,thetaOpt,J,misfit] = DynOpt_beta_and_FID(squeeze(Ydata),F,H,betaIdx,FIDIdx1, FIDIdx2,wbeta,wfid(i),S,steplength, ...
                                      windowlength,x0,theta0,options);


    all_betaopt(i,:) = thetaOpt(1,:)
    all_fidopt(i,:) = thetaOpt(2,:)
    J_all(i) = J;
end
tloopstop = toc(tloopstart);
J_all = J_all*1e4;


%plot(betaOpt)
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3, ...
                                                  1));
FID = umod.private.FID(1:Ntime);

tEnd = toc(tStart);

%Print times
tloopstop
tEnd

figure(1)
hold on;
plot(ubeta, 'DisplayName', 'True beta', 'LineWidth', 2)
for i = 1:length(wfid)
    plot(all_betaopt(i,:), 'DisplayName', "wbeta = " + num2str(wbeta) + ", wfid = " + num2str(wfid(i)))
end
legend
title("Beta")

figure(2)
hold on;
plot(FID, 'DisplayName','True FID', 'LineWidth', 2)
for i = 1:length(wfid)
    plot(all_fidopt(i,:), 'DisplayName', "wbeta = " + num2str(wbeta) + ", wfid = " + num2str(wfid(i)))
end
legend
title("FID")

return;

function y = KF_func(postrates, Nstates, index)
postrates_ = postrates;
postrates_.beta = postrates.beta(index);
postrates_.FID = postrates.FID(index);
Sys = getSyst('SIHDRe',postrates_);
Sys.Q0 = ones(Nstates,1);
Sys.qdiag = [0.05^2];
y = getFilt(Sys);
end