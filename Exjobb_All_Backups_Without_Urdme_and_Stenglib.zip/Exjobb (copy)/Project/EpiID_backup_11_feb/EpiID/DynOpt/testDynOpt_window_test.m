%testDynOpt Test of dynamic beta and how it changes when moving window.

% J. Evaeus 2022-01-12 (Adapted to EpiID framework)

% S. Engblom 2022-12-14

if ~exist('windowlength','var')
  windowlength = 40; % What is reasonable here?
  %ORIGINAL : 80
end

ntime = 365;
maxfunceval = 2700000;


if ~exist('verb','var')
  verb = false;
end

startday = 1;
endday = 60;

endday_ = startday;

% Tweaked wbeta to make posterior look OK. 
wbeta=10000;%300000;
steplength= 5;%20;
%ORIGINAL: 5

% posterior

postrates = getPost('SIHDRe','SMC');

% load filter data

load data/umod_SIHDRe

tspan = umod.tspan;
Ntime = numel(tspan);
Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)

% define data and filter periods
ixdata = startday:endday+ntime-1;

ixfilter = ixdata;

% specify observation model
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
Nstates = 5; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 

% Initial states. For now, simply initialize on true state:
x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
P0 = diag(x0+1);

[Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);

S = L.Scov;

F = cell(Ntime,1);
for m = 1:Ntime
  KF_ = KF_func(postrates,Nstates,m);
  F{m} = KF_.F;
end

H = DF.H;
betaIdx = false(obsrates.Nstates-1);
betaIdx(2,1) = true; % element of F where beta is found

beta0 = 0.1*ones(1,ntime);

if verb
  display = 'iter-detailed';
else
  display = 'off';
end
options = optimoptions(@fmincon,'MaxFunctionEvaluations',maxfunceval,...
                       'MaxIterations',6000,'Display',display,...
                       'OptimalityTolerance',2e-5);


%%% START TESTING %%%
[x0_post,betaOpt,beta_var,J,misfit] = DynOpt_win(squeeze(Ydata),F,H,betaIdx,wbeta,S,steplength, ...
                                  windowlength,x0,beta0,options);


%plot(betaOpt)
ubeta = umod.private.beta(1:Ntime).*umod.U(2,:)/sum(umod.U(2:3, ...
                                                  1));

means = zeros(length(betaOpt),1);
standard_dev = zeros(length(betaOpt),1);
nr_changes_beta = zeros(length(betaOpt),1);
beta_var = beta_var';

for j = 1:length(betaOpt)
    means(j) = mean(beta_var(j,:),"omitnan");
    standard_dev(j) = std(beta_var(j,:),"omitnan");
    nr_changes_beta(j) = nnz(~isnan(beta_var(j,:)));
end

%Plot mean and std. div.
lim1 = means + 2*standard_dev;
lim2 = means - 2*standard_dev;
x = 1:141;
betw1 = [x.', lim1];
betw2 = [x.', lim2];
combine = [betw1; flipud(betw2)];
figure(1),
subplot(2,1,1)
hold on
gray = [.7 .7 .7];
fill(combine(:,1), combine(:,2), gray, 'DisplayName', 'How betaOpt chages as window moves')
plot(x, means, 'HandleVisibility', 'off')

plot(x, ubeta, 'DisplayName', 'True beta')
legend
title("steplen: " + steplength + ", Winlen: "+ windowlength)
hold off

subplot(2,1,2)
plot(x, nr_changes_beta)
title("Number Of Changes")

%%% End TESTING %%%
return;

function y = KF_func(postrates, Nstates, index)
postrates_ = postrates;
postrates_.beta = postrates.beta(index);
postrates_.FID = postrates.FID(index);
Sys = getSyst('SIHDRe',postrates_);
Sys.Q0 = ones(Nstates,1);
Sys.qdiag = [0.05^2];
y = getFilt(Sys);
end