%testDynOpt Test of dynamic beta.

% J. Evaeus 2022-01-12 (Adapted to EpiID framework)

% S. Engblom 2022-12-14

if ~exist('windowlength','var')
  windowlength = 40; % What is reasonable here?
end

ntime = 365;
maxfunceval = 2700000;


if ~exist('verb','var')
  verb = false;
end

startday = 1;
endday = 60;

endday_ = startday;

% Tweaked wbeta to make posterior look OK. 
wbeta=10000;%300000;
steplength= 20;%20;

% posterior

postrates = getPost('SIHDRe','SMC');

% define data and filter periods
ixdata = startday:endday+ntime-1;

ixfilter = ixdata;

% specify observation model
obsrates.states = {[3] [4]}; % [H D]
obsrates.weights = {[1] [1]};
Nstates = 5; 
obsrates.Nstates = Nstates;
obsrates.R0 = ones(numel(obsrates.states),1);
obsrates.rdiag = [0.01^2];
DF = getObs(obsrates); 
Ntime = 141;

F = cell(Ntime,1);
for m = 1:Ntime
  KF_ = KF_func(postrates,Nstates,m);
  F{m} = KF_.F;
end

H = DF.H;
betaIdx = false(obsrates.Nstates-1);
betaIdx(2,1) = true; % element of F where beta is found

% Create beta as a sinus

sinamp = 0.085; % amplitude

sinshift = 0.15; % shift sin along y-axis
xvals = 1:141; % Samples

sinw = linspace(0.1, 0.2, 10); % frequency
opt_wbetas = zeros(length(sinw),1);
for freqs = 1:length(sinw)
    freqs
    sinbeta = sinamp*sin(sinw(freqs)*xvals) + sinshift;
    
    % Create filter data
    umod = gen_beta_as_sin(sinbeta);
    
    tspan = umod.tspan;
    Ntime = numel(tspan);
    Ydata = umod.U(4:5,1:Ntime); % data from (H) & (D)
    
    
    
    % Initial states. For now, simply initialize on true state:
    x0 = umod.U([1 3:end],1); % URDME: [phi (S) I H D R]
    P0 = diag(x0+1);
    
    [Z,covZ,L] = kalman(x0,P0,@KF_func,Ydata,DF,false,postrates,Nstates);
    
    S = L.Scov;
    
    beta0 = 0.1*ones(1,ntime);
    wbeta = [10000 20000 30000 40000];
    for wbetatests = 1:7
        rmsqe = zeros(length(wbeta),1);
        
        if verb
          display = 'iter-detailed';
        else
          display = 'off';
        end
        options = optimoptions(@fmincon,'MaxFunctionEvaluations',maxfunceval,...
                               'MaxIterations',6000,'Display',display,...
                               'OptimalityTolerance',2e-5);
        
        parfor i = 1:length(wbeta)
            [x0_post,betaOpt,J,misfit] = DynOpt(squeeze(Ydata),F,H,betaIdx,wbeta(i),S,steplength, ...
                                              windowlength,x0,beta0,options);
            rmsqe(i) = sqrt((1/length(betaOpt(1:60)))*sum((betaOpt(1:60)-sinbeta(1:60)).^2));
        end
        rmsqe
        [min_error, index] = min(rmsqe);
        opt_wbeta = wbeta(index);
        if wbetatests == 1
            wbeta = [opt_wbeta-8000 opt_wbeta-6000 opt_wbeta-4000 opt_wbeta-2000 opt_wbeta opt_wbeta+2000 opt_wbeta+4000 opt_wbeta+6000 opt_wbeta+8000];
        elseif wbetatests == 2
            wbeta = [opt_wbeta-1500 opt_wbeta-1000 opt_wbeta-500 opt_wbeta opt_wbeta+500 opt_wbeta+1000 opt_wbeta+1500];
        elseif wbetatests == 3
            wbeta = [opt_wbeta-400 opt_wbeta-300 opt_wbeta-200 opt_wbeta-100 opt_wbeta opt_wbeta+100 opt_wbeta+200 opt_wbeta+300 opt_wbeta+400];
        elseif wbetatests == 4
            wbeta = [opt_wbeta-80 opt_wbeta-60 opt_wbeta-40 opt_wbeta-20 opt_wbeta opt_wbeta+20 opt_wbeta+40 opt_wbeta+60 opt_wbeta+80];
        elseif wbetatests == 5
            wbeta = [opt_wbeta-15 opt_wbeta-10 opt_wbeta-5 opt_wbeta opt_wbeta+5 opt_wbeta+10 opt_wbeta+15];
        elseif wbetatests == 6
            wbeta = [opt_wbeta-4 opt_wbeta-3 opt_wbeta-2 opt_wbeta-1 opt_wbeta opt_wbeta+1 opt_wbeta+2 opt_wbeta+3 opt_wbeta+4];
        end
        wbetatests
    end
    opt_wbetas(freqs) = opt_wbeta;
end

%Plotting
figure(1)
plot(sinw, opt_wbetas, '*')
xlabel("Frequency")
ylabel("W_{\beta}")

%%% End TESTING %%%
return;

function y = KF_func(postrates, Nstates, index)
postrates_ = postrates;
postrates_.beta = postrates.beta(index);
postrates_.FID = postrates.FID(index);
Sys = getSyst('SIHDRe',postrates_);
Sys.Q0 = ones(Nstates,1);
Sys.qdiag = [0.05^2];
y = getFilt(Sys);
end